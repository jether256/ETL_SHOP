-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 12, 2023 at 07:02 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id20184901_etl`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(120) NOT NULL,
  `admin_role` varchar(120) NOT NULL,
  `admin_password` varchar(120) NOT NULL,
  `admin_email` varchar(120) NOT NULL,
  `admin_created_on` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_role`, `admin_password`, `admin_email`, `admin_created_on`) VALUES
(1, 'System Administrator', 'Administration', '12345', 'admin@edgetechuganda.com', '2021-12-14 08:38:00');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `sale_price` double NOT NULL,
  `regular_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `promotion_id` int(11) NOT NULL,
  `other_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `fnames` varchar(120) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecom_category`
--

CREATE TABLE `ecom_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(120) NOT NULL,
  `category_slag` varchar(120) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_category`
--

INSERT INTO `ecom_category` (`category_id`, `category_name`, `category_slag`, `date_created`) VALUES
(1, 'Toner Catridges', 'toner', '2021-12-06 11:58:03'),
(2, 'Drum Units', 'Drum Units', '2021-12-06 12:06:26'),
(3, 'Maintenance Kits', '', '2021-12-20 15:31:37'),
(4, 'Fuser Units', '', '2021-12-20 15:31:37'),
(5, 'Rollers', '', '2021-12-20 15:32:24');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_customer`
--

CREATE TABLE `ecom_customer` (
  `cust_id` int(11) NOT NULL,
  `cust_fname` varchar(120) NOT NULL,
  `cust_lname` varchar(120) NOT NULL,
  `cust_email` varchar(120) NOT NULL,
  `cust_phone` varchar(120) NOT NULL,
  `cust_location` varchar(120) NOT NULL,
  `cust_photo` varchar(255) NOT NULL,
  `cust_password` varchar(120) NOT NULL,
  `cust_country` varchar(120) NOT NULL,
  `cust_created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `veri_code` varchar(300) NOT NULL,
  `status` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_customer`
--

INSERT INTO `ecom_customer` (`cust_id`, `cust_fname`, `cust_lname`, `cust_email`, `cust_phone`, `cust_location`, `cust_photo`, `cust_password`, `cust_country`, `cust_created_on`, `veri_code`, `status`) VALUES
(13, 'john', 'mutale', 'mutalejether@gmail.com', '0784440934', 'kira', '', 'a280aaa0daa9963b411128c8293dcafc276a5d9972951d3d771749b52c36ff69', 'uganda', '2023-05-12 05:57:27', '40563', 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_favorite`
--

CREATE TABLE `ecom_favorite` (
  `fav_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `sale_price` double NOT NULL,
  `regular_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `promotion_id` int(11) NOT NULL,
  `other_note` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ecom_favorite`
--

INSERT INTO `ecom_favorite` (`fav_id`, `product_id`, `sale_price`, `regular_price`, `quantity`, `customer_id`, `promotion_id`, `other_note`) VALUES
(1, 3, 50000, 60000, 1, 12, 0, ''),
(2, 4, 65000, 70000, 1, 12, 0, ''),
(3, 14, 10000, 400000, 1, 12, 0, ''),
(4, 6, 70000, 80000, 1, 12, 0, ''),
(5, 1, 90000, 100000, 1, 12, 0, ''),
(6, 16, 70000, 700000, 1, 12, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_order`
--

CREATE TABLE `ecom_order` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `order_status` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `transaction_id` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `method` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ecom_order`
--

INSERT INTO `ecom_order` (`order_id`, `customer_id`, `payment_method_id`, `order_status`, `transaction_id`, `amount`, `date_created`, `shipping_id`, `method`) VALUES
(1, 12, 3, 'Pending', 'O291412034', 120000, '2023-05-10 12:28:36', 1, 'Cash on Delivery'),
(2, 12, 3, 'Pending', 'K487563078', 170000, '2023-05-10 12:57:06', 1, 'Cash on Delivery'),
(3, 12, 3, 'Confirmed', 'D890658199', 3140000, '2023-05-10 13:38:29', 1, 'Cash on Delivery'),
(4, 12, 3, 'Confirmed', 'Y739721643', 90000, '2023-05-10 14:19:39', 1, 'Cash on Delivery'),
(5, 12, 3, 'Pending', 'Z871542970', 3530000, '2023-05-10 18:22:14', 1, 'Cash on Delivery'),
(6, 12, 3, 'Pending', 'Z613459376', 1035000, '2023-05-10 18:26:33', 1, 'Cash on Delivery'),
(7, 12, 3, 'Pending', 'H947910537', 1295000, '2023-05-11 07:17:20', 1, 'Cash on Delivery'),
(8, 12, 3, 'Pending', 'J950973206', 5270000, '2023-05-11 07:21:06', 1, 'Cash on Delivery'),
(9, 12, 3, 'Pending', 'A468676836', 950000, '2023-05-11 13:18:03', 1, 'Cash on Delivery'),
(10, 12, 3, 'Pending', 'T806119771', 950000, '2023-05-11 13:18:03', 1, 'Cash on Delivery'),
(11, 13, 3, 'Canceled', 'T985178343', 170000, '2023-05-12 06:09:07', 2, 'Cash on Delivery');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_order_items`
--

CREATE TABLE `ecom_order_items` (
  `id` int(11) NOT NULL,
  `order_id` varchar(300) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_order_items`
--

INSERT INTO `ecom_order_items` (`id`, `order_id`, `product_id`, `quantity`, `unit_price`) VALUES
(1, 'O291412034', 1, 1, 90000),
(2, 'O291412034', 2, 1, 30000),
(3, 'K487563078', 95, 1, 170000),
(4, 'D890658199', 94, 1, 130000),
(5, 'D890658199', 92, 1, 1400000),
(6, 'D890658199', 90, 1, 20000),
(7, 'D890658199', 91, 1, 1400000),
(8, 'D890658199', 89, 1, 190000),
(9, 'Y739721643', 1, 1, 90000),
(10, 'Z871542970', 86, 1, 210000),
(11, 'Z871542970', 87, 1, 250000),
(12, 'Z871542970', 92, 1, 1400000),
(13, 'Z871542970', 93, 1, 1500000),
(14, 'Z871542970', 95, 1, 170000),
(15, 'Z613459376', 86, 1, 210000),
(16, 'Z613459376', 88, 1, 150000),
(17, 'Z613459376', 87, 1, 250000),
(18, 'Z613459376', 89, 1, 190000),
(19, 'Z613459376', 84, 1, 150000),
(20, 'Z613459376', 82, 1, 85000),
(21, 'H947910537', 2, 15, 30000),
(22, 'H947910537', 4, 13, 65000),
(23, 'J950973206', 95, 3, 170000),
(24, 'J950973206', 93, 3, 1500000),
(25, 'J950973206', 94, 2, 130000),
(26, 'A468676836', 1, 5, 90000),
(27, 'T806119771', 1, 5, 90000),
(28, 'A468676836', 87, 2, 250000),
(29, 'T806119771', 87, 2, 250000),
(30, 'T985178343', 95, 1, 170000);

-- --------------------------------------------------------

--
-- Table structure for table `ecom_product`
--

CREATE TABLE `ecom_product` (
  `pid` int(11) NOT NULL,
  `pname` varchar(120) NOT NULL,
  `pregular_price` double NOT NULL,
  `psale_price` double NOT NULL,
  `category_id` int(11) NOT NULL,
  `pdiscount_rate` int(11) NOT NULL,
  `prating` int(11) NOT NULL,
  `pimage1` varchar(120) NOT NULL,
  `pimage2` varchar(120) NOT NULL,
  `pimage3` varchar(120) NOT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `pavailability` int(11) NOT NULL,
  `pdescription` text NOT NULL,
  `promotion_id` int(11) NOT NULL,
  `pdate_created` datetime NOT NULL DEFAULT current_timestamp(),
  `subcategory_id` int(11) NOT NULL,
  `model_id` varchar(120) NOT NULL,
  `featured` int(11) NOT NULL DEFAULT 0,
  `return_policy` text NOT NULL,
  `psdescription` text NOT NULL,
  `end` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_product`
--

INSERT INTO `ecom_product` (`pid`, `pname`, `pregular_price`, `psale_price`, `category_id`, `pdiscount_rate`, `prating`, `pimage1`, `pimage2`, `pimage3`, `manufacturer_id`, `store_id`, `pavailability`, `pdescription`, `promotion_id`, `pdate_created`, `subcategory_id`, `model_id`, `featured`, `return_policy`, `psdescription`, `end`) VALUES
(1, 'CANON Toner 2199C002AA', 100000, 90000, 1, 0, 0, 'toner/canon/2199C002AA/main.jpg', 'toner/canon/2199C002AA/view1.jpg', 'toner/canon/2199C002AA/view2.jpg', 3, 0, 1, 'The Canon 052 and 052H black toner cartridges used by the MF421dw are easy to use, easy to recycle and very cost-effective. One 052 replacement cartridge produces 3,100 A4 pages, while the 052H produces an amazing 9,200 pages. This works out at about 1.5 p per page of laser-quality black and white printing.\r\n', 0, '2021-12-20 06:47:50', 1, '2199C002AA', 1, '', 'The Canon 052 and 052H black toner cartridges used by the MF421dw are easy to use, easy to recycle and very cost-effective. One 052 replacement cartridge produces 3,100 A4 pages, while the 052H produces an amazing 9,200 pages. This works out at about 1.5 p per page of laser-quality black and white printing.\r\n', '2021-12-20 06:47:50'),
(2, 'TOSHIBA Toner T-FC210UY', 40000, 30000, 1, 0, 0, 'toner/toshiba/T-FC210UY/main.jpg', 'toner/toshiba/T-FC210UY/view1.jpg', 'toner/toshiba/T-FC210UY/view2.jpg', 2, 1, 1, 'A yellow toner cartridge that is designed to work well with the e-Studio 2010AC, 2510AC series colour multifunction printers with a standard yield of 33,600 pages approximately. ', 0, '2021-12-20 07:24:10', 2, 'T-FC210UY', 1, '', 'A yellow toner cartridge that is designed to work well with the e-Studio 2010AC, 2510AC series colour multifunction printers with a standard yield of 33,600 pages approximately. ', '2021-12-20 07:24:10'),
(3, 'CANON Toner CEXV54', 60000, 50000, 1, 0, 0, 'toner/canon/CEXV54/main.jpg', 'toner/canon/CEXV54/view1.jpg', 'toner/canon/CEXV54/view2.jpg', 3, 1, 1, 'Canon black high yield toner Cartridge Toner for Canon IR C3025i - C3125i 15,000 yield 10,000 pages @ 5%. Also for use in Canon imageRUNNER Advance C 3025 i and C 3125 i and others', 0, '2021-12-20 07:24:10', 1, 'CEXV54', 1, '', 'Canon black high yield toner Cartridge Toner for Canon IR C3025i - C3125i 15,000 yield 10,000 pages @ 5%. Also for use in Canon imageRUNNER Advance C 3025 i and C 3125 i and others', '2021-12-20 07:24:10'),
(4, 'HP Toner CE255X', 70000, 65000, 1, 0, 0, 'toner/hp/CE255X/main.jpg', 'toner/hp/CE255X/view1.jpg', 'toner/hp/CE255X/view2.jpg', 4, 1, 1, 'Compatible Black Toner Cartridge yields 12,500 estimated pages @ 5%. HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Enterprise P3015, HP LaserJet Enterprise P3015d, HP LaserJet Enterprise P3015dn, HP LaserJet Enterprise P3015x, HP LaserJet Pro MFP M521dn.', 0, '2021-12-20 07:24:10', 1, 'CE255X', 1, '', 'Compatible Black Toner Cartridge yields 12,500 estimated pages @ 5%. HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Enterprise P3015, HP LaserJet Enterprise P3015d, HP LaserJet Enterprise P3015dn, HP LaserJet Enterprise P3015x, HP LaserJet Pro MFP M521dn.', '2021-12-20 07:24:10'),
(5, 'HP Fuser Unit RM1-8508-010CN', 90839, 89003, 4, 0, 0, 'fuser_units/hp/RM1-8508-010CN/main.jpg', 'fuser_units/hp/RM1-8508-010CN/view1.jpg', 'fuser_units/hp/RM1-8508-010CN/view2.jpg', 4, 1, 1, 'Genuine 110 / 120 Volt Fuser Unit HP Fuser Assembly HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Pro MFP M521dn.', 0, '2021-12-20 07:24:10', 0, 'RM1-8508-010CN', 1, '', 'Genuine 110 / 120 Volt Fuser Unit HP Fuser Assembly HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Pro MFP M521dn.', '2021-12-20 07:24:10'),
(6, 'HP Toner CE255X', 80000, 70000, 1, 0, 0, 'toner/hp/CE255X/main.jpg', 'toner/hp/CE255X/view1.jpg', 'toner/hp/CE255X/view2.jpg', 4, 0, 0, 'Compatible Black Toner Cartridge yields 12,500 estimated pages @ 5%. HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Enterprise P3015, HP LaserJet Enterprise P3015d, HP LaserJet Enterprise P3015dn, HP LaserJet Enterprise P3015x, HP LaserJet Pro MFP M521dn.', 0, '2021-12-20 07:24:10', 1, 'CE255X', 0, '', 'Compatible Black Toner Cartridge yields 12,500 estimated pages @ 5%. HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Enterprise P3015, HP LaserJet Enterprise P3015d, HP LaserJet Enterprise P3015dn, HP LaserJet Enterprise P3015x, HP LaserJet Pro MFP M521dn.', '2021-12-20 07:24:10'),
(7, 'HP Rollers J8J95A', 90822, 90000, 5, 0, 0, 'rollers/hp/J8J95A/main.jpg', 'rollers/hp/J8J95A/view1.jpg', 'rollers/hp/J8J95A/view2.jpg', 4, 0, 0, 'Genuine ADF Roller Kit for HP Color LaserJet Enterprise MFP M681dh it includes Pickup/Feed Roller Assembly with Separation Roller and yields 150,000 estimated pages.', 0, '2021-12-20 07:24:10', 0, 'J8J95A', 0, '', 'Genuine ADF Roller Kit for HP Color LaserJet Enterprise MFP M681dh it includes Pickup/Feed Roller Assembly with Separation Roller and yields 150,000 estimated pages.', '2021-12-20 07:24:10'),
(8, 'CANON Drum units 475C003', 70000, 40000, 2, 0, 0, 'drum_units/canon/475C003/main.jpg', 'drum_units/canon/475C003/view1.jpg', 'drum_units/canon/475C003/view2.jpg', 3, 1, 1, 'Genuine drum unit for Canon imageRUNNER ADVANCE 4535i-4525i estimated to yield 334,000 pages and 4551i-4545i estimated to yield 298,000 pages.', 0, '2021-12-20 07:24:10', 0, '475C003', 0, '', 'Genuine drum unit for Canon imageRUNNER ADVANCE 4535i-4525i estimated to yield 334,000 pages and 4551i-4545i estimated to yield 298,000 pages.', '2021-12-20 07:24:10'),
(9, 'HP Maintenance kits CF116-67903', 700000, 60000, 3, 0, 0, 'maintenance_kits/hp/CF116-67903/main.jpg', 'maintenance_kits/hp/CF116-67903/view1.jpg', 'maintenance_kits/hp/CF116-67903/view2.jpg', 4, 1, 1, 'Genuine 110/120 Volt Maintenance Kit for HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Pro MFP M521dn it includes: (1)Fuser Assembly [RM1-8508-000], (1)Transfer Roller, (1)Tray 1 Roller, (1) Tray 1 Separation Pad and Separation Pad', 0, '2021-12-20 08:21:56', 0, 'CF116-67903', 1, '', 'Genuine 110/120 Volt Maintenance Kit for HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Pro MFP M521dn it includes: (1)Fuser Assembly [RM1-8508-000], (1)Transfer Roller, (1)Tray 1 Roller, (1) Tray 1 Separation Pad and Separation Pad', '2021-12-20 08:21:56'),
(10, 'KYOCERA Maintenance kits MK-3102', 10000, 5000, 3, 0, 0, 'maintenance_kits/kyocera/MK-3102/main.jpg', 'maintenance_kits/kyocera/MK-3102/view1.jpg', 'maintenance_kits/kyocera/MK-3102/view2.jpg', 3, 1, 1, 'Genuine Maintenance Kit for Kyocera ECOSYS M3540idn and also fits these Kyocera models Kyocera ECOSYS M3040idn, Kyocera FS-2100DN, Kit includes Drum Unit [302MS93042], Developer Unit [302LV93080], Fuser Unit [302MS93094], Separation / Retard Roller Assembly [302F909171], Feed Roller Assembly [302LV94270], Transfer Roller [302LV94130]', 0, '2021-12-20 08:26:40', 0, 'MK-3102', 0, '', 'Genuine Maintenance Kit for Kyocera ECOSYS M3540idn and also fits these Kyocera models Kyocera ECOSYS M3040idn, Kyocera FS-2100DN, Kit includes Drum Unit [302MS93042], Developer Unit [302LV93080], Fuser Unit [302MS93094], Separation / Retard Roller Assembly [302F909171], Feed Roller Assembly [302LV94270], Transfer Roller [302LV94130]', '2021-12-20 08:26:40'),
(11, 'KYOCERA Maintenance kits MK-6117', 200000, 150000, 3, 0, 0, 'maintenance_kits/kyocera/MK-6117/main.jpg', 'maintenance_kits/kyocera/MK-6117/view1.jpg', 'maintenance_kits/kyocera/MK-6117/view2.jpg', 5, 1, 1, 'Genuine maintenance kit for Kyocera ECOSYS M4132idn 300K and Kyocera ECOSYS M4125idn the kit includes developer unit, drum unit, fuser unit, primary feed unit, separation pad, MPF Roller, registration cleaner, transfer unit. It yields 300k estimated copies.', 0, '2021-12-20 08:32:59', 0, 'MK-6117', 1, '', 'Genuine maintenance kit for Kyocera ECOSYS M4132idn 300K and Kyocera ECOSYS M4125idn the kit includes developer unit, drum unit, fuser unit, primary feed unit, separation pad, MPF Roller, registration cleaner, transfer unit. It yields 300k estimated copies.', '2021-12-20 08:32:59'),
(12, 'KYOCERA Maintenance kits MK-7127', 300000, 150000, 3, 0, 0, 'maintenance_kits/kyocera/MK-7127/main.jpg', 'maintenance_kits/kyocera/MK-7127/view1.jpg', 'maintenance_kits/kyocera/MK-7127/view2.jpg', 5, 1, 1, 'Genuine maintenance kit for Kyocera TASKalfa 3212i and Kyocera TASKalfa 4012i the Kit includes Drum Unit [302V693020], Developer Unit [302V693010], Transfer Roller Unit [302V6930702], Fuser Unit [302693040] and yields 600K estimated pages.', 0, '2021-12-20 08:32:59', 0, 'MK-7127', 0, '', 'Genuine maintenance kit for Kyocera TASKalfa 3212i and Kyocera TASKalfa 4012i the Kit includes Drum Unit [302V693020], Developer Unit [302V693010], Transfer Roller Unit [302V6930702], Fuser Unit [302693040] and yields 600K estimated pages.', '2021-12-20 08:32:59'),
(13, 'KYOCERA Maintenance kits MK-8115A', 400000, 300000, 3, 0, 0, 'maintenance_kits/kyocera/MK-8115A/main.jpg', 'maintenance_kits/kyocera/MK-8115A/view1.jpg', 'maintenance_kits/kyocera/MK-8115A/view2.jpg', 5, 1, 1, 'Genuine Maintenance Kit Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn.The kit includes: Primary Feed Unit [302K394480], DK-8115 [302P393060], DV-8115K [302P393030], TR-8115A [302P393100], FK-8115 [302P393073], Registration Cleaner [302K094400], TR-8115B [302P393010]. It yields 200,000 Page.', 0, '2021-12-20 08:36:21', 0, 'MK-8115A', 0, '', 'Genuine Maintenance Kit Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn.The kit includes: Primary Feed Unit [302K394480], DK-8115 [302P393060], DV-8115K [302P393030], TR-8115A [302P393100], FK-8115 [302P393073], Registration Cleaner [302K094400], TR-8115B [302P393010]. It yields 200,000 Page.', '2021-12-20 08:36:21'),
(14, 'CANON Toner 2725C001AA', 400000, 10000, 1, 0, 0, 'toner/canon/2725C001AA/main.jpg', 'toner/canon/2725C001AA/view1.jpg', 'toner/canon/2725C001AA/view2.jpg', 3, 1, 1, 'Genuine Black Toner Cartridge for Canon imageRUNNER ADVANCE DX 527iFZ. It yields 51,500 estimated pages @ 5% and also fits in these canon models Canon imageRUNNER ADVANCE 525iF II, Canon imageRUNNER ADVANCE 525iF III, Canon imageRUNNER ADVANCE 525iFZ II, Canon imageRUNNER ADVANCE 525iFZ III, Canon imageRUNNER ADVANCE 615iF II, Canon imageRUNNER ADVANCE 615iF III', 0, '2021-12-20 08:55:25', 1, '2725C001AA', 0, '', 'Genuine Black Toner Cartridge for Canon imageRUNNER ADVANCE DX 527iFZ. It yields 51,500 estimated pages @ 5% and also fits in these canon models Canon imageRUNNER ADVANCE 525iF II, Canon imageRUNNER ADVANCE 525iF III, Canon imageRUNNER ADVANCE 525iFZ II, Canon imageRUNNER ADVANCE 525iFZ III, Canon imageRUNNER ADVANCE 615iF II, Canon imageRUNNER ADVANCE 615iF III', '2021-12-20 08:55:25'),
(15, 'CANON Toner 3009C002', 100000, 90000, 1, 0, 0, 'toner/canon/3009C002/main.jpg', 'toner/canon/3009C002/view1.jpg', 'toner/canon/3009C002/view2.jpg', 3, 1, 1, 'Canon toner cartridge is guaranteed to work with these models Canon toner cartridge for use in Canon i-SENSYS LBP-223 dw/ LBP-226 dw and others. It yields 3100 estimated pages @ 5%.', 0, '2021-12-20 08:58:00', 1, '3009C002', 0, 'Canon toner cartridge is guaranteed to work with these models Canon toner cartridge for use in Canon i-SENSYS LBP-223 dw/ LBP-226 dw and others. It yields 3100 estimated pages @ 5%.', '', '2021-12-20 08:58:00'),
(16, 'CANON Toner 3010C001', 700000, 70000, 1, 0, 0, 'toner/canon/3010C001/main.jpg', 'toner/canon/3010C001/view1.jpg', 'toner/canon/3010C001/view2.jpg', 3, 1, 1, 'Canon imageCLASS MF445dw black high yield toner Cartridge it works with these models Canon imageCLASS LBP226dw, Canon imageCLASS LBP227dw, Canon imageCLASS LBP228dw, Canon imageCLASS MF448dw, Canon imageCLASS MF449dw and, yield 10,000 pages @ 5%.', 0, '2021-12-20 09:17:06', 1, '3010C001', 0, '', 'Canon imageCLASS MF445dw black high yield toner Cartridge it works with these models Canon imageCLASS LBP226dw, Canon imageCLASS LBP227dw, Canon imageCLASS LBP228dw, Canon imageCLASS MF448dw, Canon imageCLASS MF449dw and, yield 10,000 pages @ 5%.', '2021-12-20 09:17:06'),
(17, 'CANON Toner CEXV54', 700000, 800000, 1, 0, 0, 'toner/canon/CEXV54/main.jpg', 'toner/canon/CEXV54/view1.jpg', 'toner/canon/CEXV54/view2.jpg', 3, 1, 1, 'Canon black high yield toner Cartridge Toner for Canon IR C3025i - C3125i 15,000 yield 10,000 pages @ 5%. Also for use in Canon imageRUNNER Advance C 3025 i and C 3125 i and others', 0, '2021-12-20 23:59:57', 1, '3010C001', 0, '', 'Canon black high yield toner Cartridge Toner for Canon IR C3025i - C3125i 15,000 yield 10,000 pages @ 5%. Also for use in Canon imageRUNNER Advance C 3025 i and C 3125 i and others', '2021-12-20 23:59:57'),
(18, 'CANON Toner GPR-38', 45000, 5000, 1, 0, 0, 'toner/canon/GPR-38/main.jpg', 'toner/canon/GPR-38/view1.jpg', 'toner/canon/GPR-38/view2.jpg', 3, 1, 1, 'Genuine Black Toner Canon imageRUNNER ADVANCE DX 6755i Cartridge yield 56,000 estimated pages @ 6%. ', 0, '2021-12-21 00:35:22', 1, 'GPR-38', 1, '', 'It works well with these models Canon imageRUNNER ADVANCE 6055, Canon imageRUNNER ADVANCE 6065, Canon imageRUNNER ADVANCE 6075, Canon imageRUNNER ADVANCE 6255, Canon imageRUNNER ADVANCE 6265, Canon imageRUNNER ADVANCE 6275, Canon imageRUNNER ADVANCE 6555i, Canon imageRUNNER ADVANCE 6555i II.', '2021-12-21 00:35:22'),
(19, 'CANON Toner GPR-57', 10000, 1000, 1, 0, 0, 'toner/canon/GPR-57/main.jpg', 'toner/canon/GPR-57/view1.jpg', 'toner/canon/GPR-57/view2.jpg', 3, 1, 1, 'Genuine Black Toner Cartridge for Canon imageRUNNER ADVANCE DX 4735i yields 42,100 estimated pages @ 6%. It also fits in Canon imageRUNNER ADVANCE 4525i II, Canon imageRUNNER ADVANCE 4525i III, Canon imageRUNNER ADVANCE 4535i, Canon imageRUNNER ADVANCE 4535i II, Canon imageRUNNER ADVANCE 4535i III, Canon imageRUNNER ADVANCE 4545i, Canon imageRUNNER ADVANCE 4545i II.', 0, '2021-12-21 00:35:22', 1, 'GPR-57', 0, '', 'It also fits in Canon imageRUNNER ADVANCE 4525i II, Canon imageRUNNER ADVANCE 4525i III, Canon imageRUNNER ADVANCE 4535i, Canon imageRUNNER ADVANCE 4535i II, Canon imageRUNNER ADVANCE 4535i III, Canon imageRUNNER ADVANCE 4545i, Canon imageRUNNER ADVANCE 4545i II.', '2021-12-21 00:35:22'),
(20, 'HP Toner CE255X', 500000, 400000, 1, 0, 0, 'toner/hp/CE255X/main.jpg', 'toner/hp/CE255X/view1.jpg', 'toner/hp/CE255X/view2.jpg', 4, 1, 1, 'Compatible Black Toner Cartridge yields 12,500 estimated pages @ 5%. HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Enterprise P3015, HP LaserJet Enterprise P3015d, HP LaserJet Enterprise P3015dn, HP LaserJet Enterprise P3015x, HP LaserJet Pro MFP M521dn.', 0, '2021-12-21 00:55:26', 1, 'CE255X', 1, '', 'Compatible Black Toner Cartridge yields 12,500 estimated pages @ 5%. HP LaserJet Enterprise 500 MFP M525dn, HP LaserJet Enterprise 500 MFP M525f, HP LaserJet Enterprise Flow MFP M525c, HP LaserJet Enterprise P3015, HP LaserJet Enterprise P3015d, HP LaserJet Enterprise P3015dn, HP LaserJet Enterprise P3015x, HP LaserJet Pro MFP M521dn.', '2021-12-21 00:55:26'),
(21, 'HP Toner CF259X', 900000, 850000, 1, 0, 0, 'toner/hp/CF259X/main.jpg', 'toner/hp/CF259X/view1.jpg', 'toner/hp/CF259X/view2.jpg', 4, 1, 1, 'Black and White Laser Toner Printer Cartridges for HP LaserJet Pro M404n, M404dn, M404dw, M428dw, HP LaserJet Pro MFP M428dn, M428fdw. It is exceptionally reliable and has consistent print quality with an estimated yield of 10,000 per cartridge.', 0, '2021-12-21 00:55:26', 0, 'CF259X', 1, '', 'Black and White Laser Toner Printer Cartridges for HP LaserJet Pro M404n, M404dn, M404dw, M428dw, HP LaserJet Pro MFP M428dn, M428fdw. It is exceptionally reliable and has consistent print quality with an estimated yield of 10,000 per cartridge.', '2021-12-21 00:55:26'),
(22, 'HP Toner CF289X', 1000000, 900000, 1, 0, 0, 'toner/hp/CF289X/main.jpg', 'toner/hp/CF289X/view1.jpg', 'toner/hp/CF289X/view2.jpg', 4, 1, 1, 'Black high yield toner cartridge for HP LaserJet Enterprise M507dn. It yields 10,000 estimated pages @ 5% and also fits these models: HP LaserJet Enterprise Flow MFP M528c, HP LaserJet Enterprise Flow MFP M528z, HP LaserJet Enterprise M507dn, HP LaserJet Enterprise M507dng, HP LaserJet Enterprise M507n, HP LaserJet Enterprise M507x.', 0, '2021-12-21 01:29:26', 1, 'CF289X', 1, '', 'Black high yield toner cartridge for HP LaserJet Enterprise M507dn. It yields 10,000 estimated pages @ 5% and also fits these models: HP LaserJet Enterprise Flow MFP M528c, HP LaserJet Enterprise Flow MFP M528z, HP LaserJet Enterprise M507dn, HP LaserJet Enterprise M507dng, HP LaserJet Enterprise M507n, HP LaserJet Enterprise M507x.', '2021-12-21 01:29:26'),
(23, 'HP Toner CF451A', 0, 100000, 0, 0, 0, 'toner/hp/CF451A/main.jpg', 'toner/hp/CF451A/view1.jpg', 'toner/hp/CF451A/view2.jpg', 4, 1, 1, 'Compatible Cyan Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh estimated yields 10,500 pages @ 5%. Also fits these models: HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M652n, HP Color Laserjet Enterprise M653dh.', 1, '2021-12-21 01:29:26', 4, 'CF451A', 0, '', 'Compatible Cyan Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh estimated yields 10,500 pages @ 5%. Also fits these models: HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M652n, HP Color Laserjet Enterprise M653dh.', '2021-12-21 01:29:26'),
(24, 'HP Toner CF452A', 60000, 50000, 1, 0, 0, 'toner/hp/CF452A/main.jpg', 'toner/hp/CF452A/view1.jpg', 'toner/hp/CF452A/view2.jpg', 4, 1, 1, 'Compatible Yellow Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh yields 10,500 estimated pages @ 5%. HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M652n, HP Color Laserjet Enterprise M653dh.', 0, '2021-12-21 01:29:26', 2, 'CF452A', 1, '', 'Compatible Yellow Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh yields 10,500 estimated pages @ 5%. HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M652n, HP Color Laserjet Enterprise M653dh.', '2021-12-21 01:29:26'),
(25, 'HP Toner CF453A', 100000, 90000, 1, 0, 0, 'toner/hp/CF453A/main.jpg', 'toner/hp/CF453A/view1.jpg', 'toner/hp/CF453A/view2.jpg', 4, 1, 1, 'Compatible Magenta Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh yields 10,500 estimated pages @ 5%. It fits these models: HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M652n, HP Color Laserjet Enterprise M653dh.', 0, '2021-12-21 01:29:26', 3, 'CF453A', 0, '', 'Compatible Magenta Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh yields 10,500 estimated pages @ 5%. It fits these models: HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M652n, HP Color Laserjet Enterprise M653dh.', '2021-12-21 01:29:26'),
(26, 'HP Toner CF470X', 20000, 10000, 1, 0, 0, 'toner/hp/CF470X/main.jpg', 'toner/hp/CF470X/view1.jpg', 'toner/hp/CF470X/view2.jpg', 4, 1, 1, 'Compatible Black Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh. It yields 28,000 estimated pages @ 5% and also fits in HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color LaserJet Enterprise MFP M681f.', 0, '2021-12-21 01:29:26', 1, 'CF470X', 1, '', 'Compatible Black Toner Cartridge for HP Color LaserJet Enterprise MFP M681dh. It yields 28,000 estimated pages @ 5% and also fits in HP Color LaserJet Enterprise Flow MFP M681f, HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color LaserJet Enterprise MFP M681f.', '2021-12-21 01:29:26'),
(27, 'KYOCERA Toner TK-3102', 75000, 70000, 1, 0, 0, 'toner/kyocera/TK-3102/main.jpg', 'toner/kyocera/TK-3102/view1.jpg', 'toner/kyocera/TK-3102/view2.jpg', 5, 1, 1, 'Black toner cartridge (Genuine) for Kyocera ECOSYS M3540idn. It also fits in Kyocera FS-2100DN and Kyocera ECOSYS M3040idn yielding 12,500 Estimated pages @ 5% the package includes a waste toner container.', 0, '2021-12-21 01:29:26', 1, 'TK-3102', 0, '', 'Black toner cartridge (Genuine) for Kyocera ECOSYS M3540idn. It also fits in Kyocera FS-2100DN and Kyocera ECOSYS M3040idn yielding 12,500 Estimated pages @ 5% the package includes a waste toner container.', '2021-12-21 01:29:26'),
(28, 'KYOCERA Toner TK-6117', 150000, 100000, 1, 0, 0, 'toner/kyocera/TK-6117/main.jpg', 'toner/kyocera/TK-6117/view1.jpg', 'toner/kyocera/TK-6117/view2.jpg', 5, 1, 1, 'Black toner cartridge (Compatible) for Kyocera ECOSYS M4132idn and Kyocera ECOSYS M4125idn. It yields 15,000 estimated pages @ 5% also includes (2) waste toner containers.', 0, '2021-12-21 01:29:26', 1, 'TK-6117', 1, '', 'Black toner cartridge (Compatible) for Kyocera ECOSYS M4132idn and Kyocera ECOSYS M4125idn. It yields 15,000 estimated pages @ 5% also includes (2) waste toner containers.', '2021-12-21 01:29:26'),
(29, 'KYOCERA Toner TK-7127', 180000, 150000, 1, 0, 0, 'toner/kyocera/TK-7127/main.jpg', 'toner/kyocera/TK-7127/view1.jpg', 'toner/kyocera/TK-7127/view2.jpg', 5, 1, 1, 'Genuine black toner cartridge for Kyocera TASKalfa 3212i and also works in Copystar CS3212i. It yields 20,000 estimated pages @ 6% includes two waste toner containers.', 0, '2021-12-21 01:29:26', 1, 'TK-7127', 0, '', 'Genuine black toner cartridge for Kyocera TASKalfa 3212i and also works in Copystar CS3212i. It yields 20,000 estimated pages @ 6% includes two waste toner containers.', '2021-12-21 01:29:26'),
(30, 'KYOCERA Toner TK-8117C', 10000, 5000, 0, 0, 0, 'toner/kyocera/TK-8117C/main.jpg', 'toner/kyocera/TK-8117C/view1.jpg', 'toner/kyocera/TK-8117C/view2.jpg', 5, 1, 1, 'Cyan toner cartridge for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. The item dimensions LxWxH is 23.42 x 3.74 x 3.74 inches it weighs 0.64 Kilograms and yield 6,000 approximated pages @ 5% average coverage. It also includes a waste toner container.', 0, '2021-12-21 01:29:26', 1, 'TK-8117C', 0, '', 'Cyan toner cartridge for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. The item dimensions LxWxH is 23.42 x 3.74 x 3.74 inches it weighs 0.64 Kilograms and yield 6,000 approximated pages @ 5% average coverage. It also includes a waste toner container.', '2021-12-21 01:29:26'),
(31, 'KYOCERA Toner TK-8117K', 300000, 250000, 1, 0, 0, 'toner/kyocera/TK-8117K/main.jpg', 'toner/kyocera/TK-8117K/view1.jpg', 'toner/kyocera/TK-8117K/view2.jpg', 5, 1, 1, 'This black toner cartridge is guaranteed to work with your Kyocera ECOSYS M8124cidn printer. ECOSYS M8124cidn cartridges are ideal replacements for original Kyocera ECOSYS M8124cidn Toner Cartridges as they are cheaper and come with a 100% satisfaction guarantee. It yields 12,000 estimated pages ', 0, '2021-12-21 01:29:26', 1, 'TK-8117K', 0, '', 'This black toner cartridge is guaranteed to work with your Kyocera ECOSYS M8124cidn printer. ECOSYS M8124cidn cartridges are ideal replacements for original Kyocera ECOSYS M8124cidn Toner Cartridges as they are cheaper and come with a 100% satisfaction guarantee. It yields 12,000 estimated pages ', '2021-12-21 01:29:26'),
(32, 'KYOCERA Toner TK-8117M', 120000, 100000, 1, 0, 0, 'toner/kyocera/TK-8117M/main.jpg', 'toner/kyocera/TK-8117M/view1.jpg', 'toner/kyocera/TK-8117M/view2.jpg', 5, 1, 1, 'Magenta toner cartridge for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. It yields 6,000 approximated pages @ 5% average coverage. It also includes a waste toner container.', 0, '2021-12-21 02:00:04', 3, 'TK-8117M', 1, '', 'Magenta toner cartridge for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. It yields 6,000 approximated pages @ 5% average coverage. It also includes a waste toner container.', '2021-12-21 02:00:04'),
(33, 'KYOCERA Toner TK-8117Y', 110000, 100000, 1, 0, 0, 'toner/kyocera/TK-8117Y/main.jpg', 'toner/kyocera/TK-8117Y/view1.jpg', 'toner/kyocera/TK-8117Y/view2.jpg', 5, 1, 1, 'Yellow toner cartridge for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. It yields 6,000 approximated pages @ 5% average coverage. It also includes a waste toner container.', 0, '2021-12-21 02:00:04', 2, 'TK-8117Y', 0, '', 'Yellow toner cartridge for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. It yields 6,000 approximated pages @ 5% average coverage. It also includes a waste toner container.', '2021-12-21 02:00:04'),
(34, 'TOSHIBA Toner T-2323C', 150000, 140000, 1, 0, 0, 'toner/toshiba/T-2323C/view3.jpg', 'toner/toshiba/T-2323C/view2.jpg', 'toner/toshiba/T-2323C/view1.jpg', 2, 1, 1, 'Toner Cartridge T-2323C genuine for Toshiba e-Studio 2523A, e-Studio 2523AD, e-Studio 2323AM, e-Studio 2823AM, e-Studio 2329A, e-Studio 2829A. It uses laser printing technology and yields approximately 15000 Pages @5%. It is ideal for home offices or small businesses and easy to set up as well as carrying.', 0, '2021-12-21 02:00:04', 1, 'T-2323C', 0, '', 'Toner Cartridge T-2323C genuine for Toshiba e-Studio 2523A, e-Studio 2523AD, e-Studio 2323AM, e-Studio 2823AM, e-Studio 2329A, e-Studio 2829A. It uses laser printing technology and yields approximately 15000 Pages @5%. It is ideal for home offices or small businesses and easy to set up as well as carrying.', '2021-12-21 02:00:04'),
(35, 'TOSHIBA Toner T-2822U', 100000, 95000, 1, 0, 0, 'toner/toshiba/T-2822U/main.jpg', 'toner/toshiba/T-2822U/view1.jpg', 'toner/toshiba/T-2822U/view2.jpg', 2, 1, 1, 'Genuine black toner cartridge with an estimated yield of 17,500 pages @5% and works in Toshiba E STUDIO 2822AF, Toshiba E STUDIO 2822AM. The Toshiba T-2822U is ideal for providing the best print quality.', 0, '2021-12-21 02:00:04', 1, 'T-2822U', 0, '', 'Genuine black toner cartridge with an estimated yield of 17,500 pages @5% and works in Toshiba E STUDIO 2822AF, Toshiba E STUDIO 2822AM. The Toshiba T-2822U is ideal for providing the best print quality.', '2021-12-21 02:00:04'),
(36, 'TOSHIBA Toner T-409SU-R', 25000, 20000, 1, 0, 0, 'toner/toshiba/T-409SU-R/main.jpg', 'toner/toshiba/T-409SU-R/view1.jpg', 'toner/toshiba/T-409SU-R/view2.jpg', 2, 1, 1, 'It is a laser black Toshiba toner cartridge that is engineered to give consistent, quality output from the Toshiba printer. It is compatible with Toshiba models: e-STUDIO409S with an estimated yield of 20,000 pages @ 5%.', 0, '2021-12-21 02:00:04', 1, 'T-409SU-R', 0, '', 'It is a laser black Toshiba toner cartridge that is engineered to give consistent, quality output from the Toshiba printer. It is compatible with Toshiba models: e-STUDIO409S with an estimated yield of 20,000 pages @ 5%.', '2021-12-21 02:00:04'),
(37, 'TOSHIBA Toner T-5018U', 130000, 12000, 1, 0, 0, 'toner/toshiba/T-5018U/main.jpg', 'toner/toshiba/T-5018U/view1.jpg', 'toner/toshiba/T-5018U/view2.jpg', 2, 1, 1, 'Black Toshiba toner cartridge is estimated to make a yield of 43,900 pages @ 5%. It is manufactured to fit these Toshiba multifunctional printer models e-studio2518A, 3018A, 3518A, 4518A, and the 5018A series printers.', 0, '2021-12-21 02:00:04', 1, 'T-5018U', 0, '', 'Black Toshiba toner cartridge is estimated to make a yield of 43,900 pages @ 5%. It is manufactured to fit these Toshiba multifunctional printer models e-studio2518A, 3018A, 3518A, 4518A, and the 5018A series printers.', '2021-12-21 02:00:04'),
(38, 'TOSHIBA Toner T-6518U', 60000, 50000, 1, 0, 0, 'toner/toshiba/T-6518U/main.jpg', 'toner/toshiba/T-6518U/view1.jpg', 'toner/toshiba/T-6518U/view2.jpg', 2, 1, 1, 'This black Toshiba toner cartridge yields 106,600 estimated pages @ 5%. It is manufactured for use in these Toshiba models:e-STUDIO 5518A, 6518A, 7518A and 8518A series printers.', 0, '2021-12-21 02:00:04', 0, 'T-6518U', 0, '', 'This black Toshiba toner cartridge yields 106,600 estimated pages @ 5%. It is manufactured for use in these Toshiba models:e-STUDIO 5518A, 6518A, 7518A and 8518A series printers.', '2021-12-21 02:00:04'),
(39, 'TOSHIBA Toner T-FC210UC', 140000, 130000, 1, 0, 0, 'toner/toshiba/T-FC210UC/main.jpg', 'toner/toshiba/T-FC210UC/view1.jpg', 'toner/toshiba/T-FC210UC/view2.jpg', 2, 1, 1, 'Toshiba toner cartridge for the coloured printers yields 33,600 estimated pages @ 5%. It is designed to work in Toshiba e-Studio 2010AC, e-Studio 2510AC and ensures crisp, sharp, vibrant results every time. The cartridge is easy to install and replace.', 0, '2021-12-21 02:00:04', 3, 'T-FC210UC', 1, '', 'Toshiba toner cartridge for the coloured printers yields 33,600 estimated pages @ 5%. It is designed to work in Toshiba e-Studio 2010AC, e-Studio 2510AC and ensures crisp, sharp, vibrant results every time. The cartridge is easy to install and replace.', '2021-12-21 02:00:04'),
(40, 'TOSHIBA Toner T-FC210UK', 160000, 150000, 1, 0, 0, 'toner/toshiba/T-FC210UK/view3.jpg', 'toner/toshiba/T-FC210UK/main.jpg', 'toner/toshiba/T-FC210UK/view1.jpg', 2, 1, 1, 'Black Toshiba toner cartridge that extends the exceptional print quality and well-grounded execution for fast, professional-quality colour printing. It is engineered to fit these Toshiba models: e-Studio2510AC and 2010AC series printers. It yields 33,600 pages estimated @ 5%', 0, '2021-12-21 02:00:04', 1, 'T-FC210UK', 1, '', 'Black Toshiba toner cartridge that extends the exceptional print quality and well-grounded execution for fast, professional-quality colour printing. It is engineered to fit these Toshiba models: e-Studio2510AC and 2010AC series printers. It yields 33,600 pages estimated @ 5%', '2021-12-21 02:00:04'),
(41, 'TOSHIBA Toner T-FC210UM', 180000, 170000, 1, 0, 0, 'toner/toshiba/T-FC210UM/main.jpg', 'toner/toshiba/T-FC210UM/view1.jpg', 'toner/toshiba/T-FC210UM/view2.jpg', 2, 1, 1, 'We strive to avail you of our stock magenta toner cartridges at all times. Edge Technologies Limited will deliver your toner cartridge as soon as possible. The cartridge is designed to fit these Toshiba coloured printers: e-STUDIO2510AC and e-STUDIO2510AC and yields 33,600 pages @ 5%.', 0, '2021-12-21 02:00:04', 3, 'T-FC210UM', 0, '', 'We strive to avail you of our stock magenta toner cartridges at all times. Edge Technologies Limited will deliver your toner cartridge as soon as possible. The cartridge is designed to fit these Toshiba coloured printers: e-STUDIO2510AC and e-STUDIO2510AC and yields 33,600 pages @ 5%.', '2021-12-21 02:00:04'),
(42, 'TOSHIBA Toner T-FC210UY', 125000, 120000, 1, 0, 0, 'toner/toshiba/T-FC210UY/main.jpg', 'toner/toshiba/T-FC210UY/view1.jpg', 'toner/toshiba/T-FC210UY/view2.jpg', 2, 1, 1, 'A yellow toner cartridge that is designed to work well with the e-Studio 2010AC, 2510AC series colour multifunction printers with a standard yield of 33,600 pages approximately. ', 0, '2021-12-21 02:37:10', 2, 'T-FC210UY', 0, '', 'A yellow toner cartridge that is designed to work well with the e-Studio 2010AC, 2510AC series colour multifunction printers with a standard yield of 33,600 pages approximately. ', '2021-12-21 02:37:10'),
(43, 'TOSHIBA Toner T-FC330UC', 560000, 540000, 1, 0, 0, 'toner/toshiba/T-FC330UC/main.jpg', 'toner/toshiba/T-FC330UC/view1.jpg', 'toner/toshiba/T-FC330UC/view2.jpg', 2, 1, 1, 'Genuine Cyan Toshiba toner cartridge for use in the e-STUDIO 330AC and e-STUDIO 400AC series printers. It yields 17400 estimated pages @ 5%.', 0, '2021-12-21 02:37:10', 4, 'T-FC330UC', 0, '', 'Genuine Cyan Toshiba toner cartridge for use in the e-STUDIO 330AC and e-STUDIO 400AC series printers. It yields 17400 estimated pages @ 5%.', '2021-12-21 02:37:10'),
(44, 'TOSHIBA Toner T-FC330UK', 200000, 150000, 1, 0, 0, 'toner/toshiba/T-FC330UK/main.jpg', 'toner/toshiba/T-FC330UK/view1.jpg', 'toner/toshiba/T-FC330UK/view2.jpg', 2, 1, 1, 'This black toner cartridge works well with these Toshiba models: e-STUDIO 330AC and e-STUDIO 400AC series printers with an estimated yield of 18,400 pages @ 5%.', 0, '2021-12-21 02:37:10', 1, 'T-FC330UK', 1, '', 'This black toner cartridge works well with these Toshiba models: e-STUDIO 330AC and e-STUDIO 400AC series printers with an estimated yield of 18,400 pages @ 5%.', '2021-12-21 02:37:10'),
(45, 'TOSHIBA Toner T-FC330UM', 11000, 10000, 1, 0, 0, 'toner/toshiba/T-FC330UM/main.jpg', 'toner/toshiba/T-FC330UM/view1.jpg', 'toner/toshiba/T-FC330UM/view2.jpg', 2, 1, 1, 'Magenta toner cartridge used in the Toshiba e-Studio 330AC, e-Studio 400AC series coloured printers and, yields 17400 Pages @ 5% approximately.', 0, '2021-12-21 02:37:10', 3, 'T-FC330UM', 1, '', 'Magenta toner cartridge used in the Toshiba e-Studio 330AC, e-Studio 400AC series coloured printers and, yields 17400 Pages @ 5% approximately.', '2021-12-21 02:37:10'),
(46, 'TOSHIBA Toner T-FC330UY', 15000, 10000, 1, 0, 0, 'toner/toshiba/T-FC330UY/main.jpg', 'toner/toshiba/T-FC330UY/view1.jpg', 'toner/toshiba/T-FC330UY/view2.jpg', 2, 1, 1, 'Yellow toner cartridge suitable for use in Toshiba E-Studio 330 AC, 400 AC series coloured printers. It approximately yield 17,400 pages @ 5%.', 0, '2021-12-21 02:37:10', 2, 'T-FC330UY', 0, '', 'Yellow toner cartridge suitable for use in Toshiba E-Studio 330 AC, 400 AC series coloured printers. It approximately yield 17,400 pages @ 5%.', '2021-12-21 02:37:10'),
(47, 'TOSHIBA Toner TF-C338ECR', 170000, 150000, 1, 0, 0, 'toner/toshiba/TF-C338ECR/main.jpg', 'toner/toshiba/TF-C338ECR/view1.jpg', 'toner/toshiba/TF-C338ECR/view2.jpg', 2, 1, 1, 'Cyan toner cartridge is suitable for use in Toshiba e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 02:37:10', 4, 'TF-C338ECR', 0, '', 'Cyan toner cartridge is suitable for use in Toshiba e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 02:37:10'),
(48, 'TOSHIBA Toner TF-C338EKR', 190000, 170000, 1, 0, 0, 'toner/toshiba/TF-C338EKR/main.jpg', 'toner/toshiba/TF-C338EKR/view1.jpg', 'toner/toshiba/TF-C338EKR/view2.jpg', 2, 1, 1, 'Black Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 02:37:10', 1, 'TF-C338EKR', 0, '', 'Black Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 02:37:10'),
(49, 'TOSHIBA Toner TF-C338EMR', 210000, 20000, 1, 0, 0, 'toner/toshiba/TF-C338EMR/main.jpg', 'toner/toshiba/TF-C338EMR/view1.jpg', 'toner/toshiba/TF-C338EMR/view2.jpg', 2, 1, 1, 'Magenta Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 02:37:10', 3, 'TF-C338EMR', 0, '', 'Magenta Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 02:37:10'),
(50, 'TOSHIBA Toner TF-C338EYR', 220000, 210000, 1, 0, 0, 'toner/toshiba/TF-C338EYR/main.jpg', 'toner/toshiba/TF-C338EYR/view1.jpg', 'toner/toshiba/TF-C338EYR/view2.jpg', 2, 1, 1, 'Yellow Toshiba toner cartridge suitable for use in these Toshiba models: e-STUDIO 338AC, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 02:37:10', 2, 'TF-C338EYR', 0, '', 'Yellow Toshiba toner cartridge suitable for use in these Toshiba models: e-STUDIO 338AC, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 02:37:10'),
(51, 'TOSHIBA Toner TF-C338ECR', 100000, 9000000, 1, 0, 0, 'toner/toshiba/TF-C338ECR/main.jpg', 'toner/toshiba/TF-C338ECR/view1.jpg', 'toner/toshiba/TF-C338ECR/view2.jpg', 2, 1, 1, 'Cyan toner cartridge is suitable for use in Toshiba e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 02:37:10', 0, '', 0, '', 'Cyan toner cartridge is suitable for use in Toshiba e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 02:37:10'),
(52, 'TOSHIBA Toner TF-C415UC', 10000, 5000, 1, 0, 0, 'toner/toshiba/TF-C415UC/main.jpg', 'toner/toshiba/TF-C415UC/view1.jpg', 'toner/toshiba/TF-C415UC/view2.jpg', 2, 1, 1, 'Cyan Toshiba toner cartridge applicable in these models e-STUDIO 2515AC, 3015AC, 3515AC, 4515AC and 5015AC series coloured multifunctional printers. It yields 33,600 estimated pages @ 5%.', 0, '2021-12-21 03:12:13', 4, 'TF-C415UC', 1, '', 'Cyan Toshiba toner cartridge applicable in these models e-STUDIO 2515AC, 3015AC, 3515AC, 4515AC and 5015AC series coloured multifunctional printers. It yields 33,600 estimated pages @ 5%.', '2021-12-21 03:12:13'),
(53, 'TOSHIBA Toner TF-C415UK', 900000, 80000, 1, 0, 0, 'toner/toshiba/TF-C415UK/main.jpg', 'toner/toshiba/TF-C415UK/view1.jpg', 'toner/toshiba/TF-C415UK/view2.jpg', 2, 1, 1, 'Black toner cartridge for Toshiba e-Studio 2515AC, 3015AC, 3515AC, 4515AC and 5015AC series coloured multifunctional printers readily available at Edge Technologies limited.', 0, '2021-12-21 03:12:13', 1, 'TF-C415UK', 0, '', 'Black toner cartridge for Toshiba e-Studio 2515AC, 3015AC, 3515AC, 4515AC and 5015AC series coloured multifunctional printers readily available at Edge Technologies limited.', '2021-12-21 03:12:13'),
(54, 'TOSHIBA Toner TF-C415UM', 150000, 1200000, 1, 0, 0, 'toner/toshiba/TF-C415UM/main.jpg', 'toner/toshiba/TF-C415UM/view1.jpg', 'toner/toshiba/TF-C415UM/view2.jpg', 2, 1, 1, 'Magenta toner cartridge is engineered to bring out the best print results in the Toshiba e-Studio 2515AC, 3015AC, 3515AC, 4515AC and 5015AC. It is suitable for busy offices. It is simple to install and yields approximately 33,600 pages @ 5%.', 0, '2021-12-21 03:12:13', 3, 'TF-C415UM', 0, '', 'Magenta toner cartridge is engineered to bring out the best print results in the Toshiba e-Studio 2515AC, 3015AC, 3515AC, 4515AC and 5015AC. It is suitable for busy offices. It is simple to install and yields approximately 33,600 pages @ 5%.', '2021-12-21 03:12:13'),
(55, 'TOSHIBA Toner TF-C415UY', 300000, 15000, 1, 0, 0, 'toner/toshiba/TF-C415UY/main.jpg', 'toner/toshiba/TF-C415UY/view2.jpg', 'toner/toshiba/TF-C415UY/view2.jpg', 0, 0, 0, 'Toshiba yellow toner cartridge is compatible with the Toshiba e-STUDIO 2515AC, 3015AC, 3515AC, 4515AC, 5015AC. It approximately yield 33,600 pages @ 5%.', 0, '2021-12-21 03:12:13', 2, 'TF-C415UY', 0, '', 'Toshiba yellow toner cartridge is compatible with the Toshiba e-STUDIO 2515AC, 3015AC, 3515AC, 4515AC, 5015AC. It approximately yield 33,600 pages @ 5%.', '2021-12-21 03:12:13'),
(56, 'TOSHIBA Toner TF-C616UC', 90000, 75000, 1, 0, 0, 'toner/toshiba/TF-C616UC/main.jpg', 'toner/toshiba/TF-C616UC/view1.jpg', 'toner/toshiba/TF-C616UC/view2.jpg', 2, 1, 1, 'Cyan Toshiba toner Cartridge is engineered to perform best in these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', 0, '2021-12-21 03:12:13', 4, 'TF-C616UC', 1, '', 'Cyan Toshiba toner Cartridge is engineered to perform best in these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', '2021-12-21 03:12:13'),
(57, 'TOSHIBA Toner TF-C616UK', 500000, 450000, 1, 0, 0, 'toner/toshiba/TF-C616UK/main.jpg', 'toner/toshiba/TF-C616UK/view1.jpg', 'toner/toshiba/TF-C616UK/view2.jpg', 2, 1, 1, 'Black Toshiba toner Cartridge is engineered to perform best in these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', 0, '2021-12-21 03:12:13', 1, ' TF-C616UK', 0, '', 'Black Toshiba toner Cartridge is engineered to perform best in these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', '2021-12-21 03:12:13'),
(58, 'TOSHIBA Toner TF-C616UM', 125000, 12000, 1, 0, 0, 'toner/toshiba/TF-C616UM/main.jpg', 'toner/toshiba/TF-C616UM/view1.jpg', 'toner/toshiba/TF-C616UM/view2.jpg', 2, 1, 1, 'Magenta Toshiba toner Cartridge works well in these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', 0, '2021-12-21 03:12:13', 3, 'TF-C616UM', 0, '', 'Magenta Toshiba toner Cartridge works well in these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', '2021-12-21 03:12:13'),
(59, 'TOSHIBA Toner TF-C616UY', 1500000, 1400000, 1, 0, 0, 'toner/toshiba/TF-C616UY/main.jpg', 'toner/toshiba/TF-C616UY/view2.jpg', 'toner/toshiba/TF-C616UY/vie3.jpg', 2, 1, 1, 'Yellow Toshiba toner Cartridge is compatible with these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', 0, '2021-12-21 03:12:13', 2, 'TF-C616UY', 1, '', 'Yellow Toshiba toner Cartridge is compatible with these models e-Studio 5516AC, e-Studio 5516ACT, e-Studio 6516AC, e-Studio 6516ACT, e-Studio 7516AC, e-Studio 7516ACT. The cartridge yields approximately 39,200 pages @ 5% coverage.', '2021-12-21 03:12:13'),
(60, 'TOSHIBA Toner TF-C338EKR', 550000, 50000, 1, 0, 0, 'toner/toshiba/TF-C338EKR/main.jpg', 'toner/toshiba/TF-C338EKR/view1.jpg', 'toner/toshiba/TF-C338EKR/view2.jpg', 2, 1, 1, 'Black Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 03:12:13', 1, 'TF-C338EKR', 1, '', 'lack Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 03:12:13'),
(61, 'TOSHIBA Toner TF-C338EMR', 160000, 100000, 1, 0, 0, 'toner/toshiba/TF-C338EMR/main.jpg', 'toner/toshiba/TF-C338EMR/view1.jpg', 'toner/toshiba/TF-C338EMR/view1.jpg', 2, 1, 1, 'Magenta Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 03:12:13', 3, 'TF-C338EMR', 0, '', 'Magenta Toshiba toner cartridge best for use in these Toshiba models: e-STUDIO 338AC, 338 CP, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 03:12:13'),
(62, 'TOSHIBA Toner TF-C338EYR', 195000, 190000, 1, 0, 0, 'toner/toshiba/TF-C338EYR/main.jpg', 'toner/toshiba/TF-C338EYR/view1.jpg', 'toner/toshiba/TF-C338EYR/view2.jpg', 2, 1, 1, 'Yellow Toshiba toner cartridge suitable for use in these Toshiba models: e-STUDIO 338AC, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', 0, '2021-12-21 03:12:13', 2, 'TF-C338EYR', 0, '', 'Yellow Toshiba toner cartridge suitable for use in these Toshiba models: e-STUDIO 338AC, 338 CS, 388 CP, 388 CS series coloured printers. It approximately yields 6000 pages @ 5%.', '2021-12-21 03:12:13'),
(63, 'HP Rollers RM1-4840-000CN', 150000, 140000, 5, 0, 0, 'rollers/hp/RM1-4840-000CN/main.jpg', 'rollers/hp/RM1-4840-000CN/view1.jpg', 'rollers/hp/RM1-4840-000CN/view2.jpg', 4, 1, 1, 'Genuine Separation Roller Assembly for HP Color LaserJet Pro MFP M476dw Tray 2. It works well with HP Color LaserJet CM2320fxi, HP Color LaserJet CM2320n, HP Color LaserJet CM2320nf, HP Color LaserJet CP2025, HP Color LaserJet CP2025dn, HP Color LaserJet CP2025n, HP Color LaserJet CP2025x, HP Color LaserJet Pro MFP M476dn, HP Color LaserJet Pro MFP M476nw, HP LaserJet Pro 300 Color MFP M375nw.', 0, '2021-12-21 04:47:14', 0, ' RM1-4840-000CN', 0, '', 'Genuine Separation Roller Assembly for HP Color LaserJet Pro MFP M476dw Tray 2. It works well with HP Color LaserJet CM2320fxi, HP Color LaserJet CM2320n, HP Color LaserJet CM2320nf, HP Color LaserJet CP2025, HP Color LaserJet CP2025dn, HP Color LaserJet CP2025n, HP Color LaserJet CP2025x, HP Color LaserJet Pro MFP M476dn, HP Color LaserJet Pro MFP M476nw, HP LaserJet Pro 300 Color MFP M375nw.', '2021-12-21 04:47:14'),
(64, 'HP Rollers RM1-8047-030CN', 150000, 1300000, 5, 0, 0, 'rollers/hp/RM1-8047-030CN/main.jpg', 'rollers/hp/RM1-8047-030CN/view1.jpg', 'rollers/hp/RM1-8047-030CN/view2.jpg', 4, 1, 1, 'Genuine cassette pickup roller for HP Color LaserJet Pro MFP M476dw. It is compatible with these models HP Color LaserJet Pro CM1415fnw MFP, HP Color LaserJet Pro CP1525nw, HP Color LaserJet Pro MFP M476dn, HP Color LaserJet Pro MFP M476nw.', 0, '2021-12-21 04:47:14', 0, 'RM1-4840-000CN', 1, '', 'Genuine cassette pickup roller for HP Color LaserJet Pro MFP M476dw. It is compatible with these models HP Color LaserJet Pro CM1415fnw MFP, HP Color LaserJet Pro CP1525nw, HP Color LaserJet Pro MFP M476dn, HP Color LaserJet Pro MFP M476nw.', '2021-12-21 04:47:14'),
(65, 'KYOCERA Rollers 302F909171', 160000, 150000, 5, 0, 0, 'rollers/kyocera/302F909171/main.jpg', 'rollers/kyocera/302F909171/view1.jpg', 'rollers/kyocera/302F909171/view2.jpg', 5, 1, 1, 'Genuine separation roller for Kyocera ECOSYS M3540idn Kyocera TASKalfa 3500i, Kyocera TASKalfa 3501i, Kyocera TASKalfa 3511i Kyocera TASKalfa 3550ci, Kyocera TASKalfa 3551ci, Kyocera ECOSYS M2040dn, Kyocera ECOSYS M2540dw, Kyocera ECOSYS M2635dw, Kyocera ECOSYS M2640idw, Kyocera ECOSYS M3040idn.', 0, '2021-12-21 04:47:14', 0, '302F909171', 0, '', 'Genuine separation roller for Kyocera ECOSYS M3540idn Kyocera TASKalfa 3500i, Kyocera TASKalfa 3501i, Kyocera TASKalfa 3511i Kyocera TASKalfa 3550ci, Kyocera TASKalfa 3551ci, Kyocera ECOSYS M2040dn, Kyocera ECOSYS M2540dw, Kyocera ECOSYS M2635dw, Kyocera ECOSYS M2640idw, Kyocera ECOSYS M3040idn.', '2021-12-21 04:47:14'),
(66, 'KYOCERA Rollers 302LK94140', 150000, 11000, 0, 0, 0, 'rollers/kyocera/302LK94140/main.jpg', 'rollers/kyocera/302LK94140/view1.jpg', 'rollers/kyocera/302LK94140/view2.jpg', 5, 1, 1, 'Kyocera TASKalfa 3212i Pick-up Roller Kit (Genuine) the Kit Includes: (1) Pick-up Roller [302HN0680], (1) Feed Roller [302F906230], (1) Retard Roller [302F908171] One kit used for each cassette. Also fits these models: Kyocera TASKalfa 4012i, Copystar CS3212i, Copystar CS4012i. ', 0, '2021-12-21 04:47:14', 0, '302LK94140', 1, '', 'Kyocera TASKalfa 3212i Pick-up Roller Kit (Genuine) the Kit Includes: (1) Pick-up Roller [302HN0680], (1) Feed Roller [302F906230], (1) Retard Roller [302F908171] One kit used for each cassette. Also fits these models: Kyocera TASKalfa 4012i, Copystar CS3212i, Copystar CS4012i. ', '2021-12-21 04:47:14'),
(67, 'KYOCERA Rollers 302LV94270', 1500000, 14000, 5, 0, 0, 'rollers/kyocera/302LV94270/main.jpg', 'rollers/kyocera/302LV94270/view1.jpg', 'rollers/kyocera/302LV94270/view2.jpg', 5, 1, 1, 'Genuine feed roller ssembly holder for ECOSYS M3540idn it also fits these models Kyocera ECOSYS M3040idn, Kyocera FS-2100DN, Kyocera FS-4100DN, Kyocera FS-4200DN, Kyocera FS-4300DN.', 0, '2021-12-21 04:47:14', 0, '302LV94270', 0, '', 'Genuine feed roller ssembly holder for ECOSYS M3540idn it also fits these models Kyocera ECOSYS M3040idn, Kyocera FS-2100DN, Kyocera FS-4100DN, Kyocera FS-4200DN, Kyocera FS-4300DN.', '2021-12-21 04:47:14'),
(68, 'KYOCERA Rollers 302P194100', 10000, 9000, 5, 0, 0, 'rollers/kyocera/302P194100/main.jpg', 'rollers/kyocera/302P194100/view1.jpg', 'rollers/kyocera/302P194100/view2.jpg', 5, 1, 1, 'Pickup Feed Separation Roller Kit for TA4020i, ECOSYS M4125idn, ECOSYS M4132idn, ECOSYS M4230, ECOSYS M4226, ECOSYS M8124, ECOSYS M8130, ECOSYS M8224, ECOSYS M8228.', 0, '2021-12-21 04:47:14', 0, '302P194100', 1, '', 'Pickup Feed Separation Roller Kit for TA4020i, ECOSYS M4125idn, ECOSYS M4132idn, ECOSYS M4230, ECOSYS M4226, ECOSYS M8124, ECOSYS M8130, ECOSYS M8224, ECOSYS M8228.', '2021-12-21 04:47:14'),
(69, 'KYOCERA Rollers 33037212209', 150500, 100000, 5, 0, 0, 'rollers/kyocera/33037212209/main.jpg', 'rollers/kyocera/33037212209/view1.jpg', 'rollers/kyocera/33037212209/view2.jpg', 5, 1, 1, 'Pickup Feed Separation Roller Kit for Kyocera ECOSYS M8124cidn, M8130cidn, m8124, M8130, 8124, 8130.', 0, '2021-12-21 04:47:14', 0, '33037212209', 0, '', 'Pickup Feed Separation Roller Kit for Kyocera ECOSYS M8124cidn, M8130cidn, m8124, M8130, 8124, 8130.', '2021-12-21 04:47:14');
INSERT INTO `ecom_product` (`pid`, `pname`, `pregular_price`, `psale_price`, `category_id`, `pdiscount_rate`, `prating`, `pimage1`, `pimage2`, `pimage3`, `manufacturer_id`, `store_id`, `pavailability`, `pdescription`, `promotion_id`, `pdate_created`, `subcategory_id`, `model_id`, `featured`, `return_policy`, `psdescription`, `end`) VALUES
(70, 'TOSHIBA Rollers 6LA04042000', 130000, 100000, 5, 0, 0, 'rollers/toshiba/6LA04042000/main.jpg', 'rollers/toshiba/6LA04042000/view1.jpg', 'rollers/toshiba/6LA04042000/view2.jpg', 2, 1, 1, 'Genuine Toshiba separation roller machines use 1 per drawer. The roller is compatible with Toshiba e-STUDIO 6506AC, Toshiba e-STUDIO 6508A, Toshiba e-STUDIO 6516AC, Toshiba e-STUDIO 7516AC, Toshiba e-STUDIO 7518A, Toshiba e-STUDIO 5506AC, Toshiba e-STUDIO 5516AC, Toshiba e-STUDIO 5518A.', 0, '2021-12-21 04:47:14', 0, '6LA04042000', 1, '', 'Genuine Toshiba separation roller machines use 1 per drawer. The roller is compatible with Toshiba e-STUDIO 6506AC, Toshiba e-STUDIO 6508A, Toshiba e-STUDIO 6516AC, Toshiba e-STUDIO 7516AC, Toshiba e-STUDIO 7518A, Toshiba e-STUDIO 5506AC, Toshiba e-STUDIO 5516AC, Toshiba e-STUDIO 5518A.', '2021-12-21 04:47:14'),
(71, 'TOSHIBA Rollers 6LA04047100', 110000, 170000, 5, 0, 0, 'rollers/toshiba/6LA04047100/main.jpg', 'rollers/toshiba/6LA04047100/view3.jpg', 'rollers/toshiba/6LA04047100/view2.jpg', 2, 1, 1, 'Genuine Toshiba pickup/feed rollers for e-STUDIO 8518AToshiba. They are compatible with these models e-STUDIO 5506AC, Toshiba e-STUDIO 5508A, Toshiba e-STUDIO 5516AC, Toshiba e-STUDIO 5518A, Toshiba e-STUDIO 6506AC, Toshiba e-STUDIO 6508A, Toshiba e-STUDIO 6516AC, Toshiba e-STUDIO 6518A, Toshiba e-STUDIO 7506AC, Toshiba e-STUDIO 7508A, Toshiba e-STUDIO 7516AC, Toshiba e-STUDIO 7518A, Toshiba e-STUDIO 8508A.', 0, '2021-12-21 04:47:14', 0, '6LA04047100', 0, '', 'Genuine Toshiba pickup/feed rollers for e-STUDIO 8518AToshiba. They are compatible with these models e-STUDIO 5506AC, Toshiba e-STUDIO 5508A, Toshiba e-STUDIO 5516AC, Toshiba e-STUDIO 5518A, Toshiba e-STUDIO 6506AC, Toshiba e-STUDIO 6508A, Toshiba e-STUDIO 6516AC, Toshiba e-STUDIO 6518A, Toshiba e-STUDIO 7506AC, Toshiba e-STUDIO 7508A, Toshiba e-STUDIO 7516AC, Toshiba e-STUDIO 7518A, Toshiba e-STUDIO 8508A.', '2021-12-21 04:47:14'),
(72, 'TOSHIBA Rollers 6LJ57026000', 100000, 100000, 5, 0, 0, 'rollers/toshiba/6LJ57026000/main.jpg', 'rollers/toshiba/6LJ57026000/view1.jpg', 'rollers/toshiba/6LJ57026000/view2.jpg', 2, 1, 1, 'Genuine Toshiba feed roller (bypass Manual Feed) for e-STUDIO 3515AC. It also fits these models: Toshiba e-STUDIO 2510AC, Toshiba e-STUDIO 2518A, Toshiba e-STUDIO 3015AC, Toshiba e-STUDIO 3018A, Toshiba e-STUDIO 3518A, Toshiba e-STUDIO 4508LP, Toshiba e-STUDIO 4518A, Toshiba e-STUDIO 5015AC, Toshiba e-STUDIO 5018A.', 0, '2021-12-21 04:47:14', 0, '6LJ57026000', 0, '', 'Genuine Toshiba feed roller (bypass Manual Feed) for e-STUDIO 3515AC. It also fits these models: Toshiba e-STUDIO 2510AC, Toshiba e-STUDIO 2518A, Toshiba e-STUDIO 3015AC, Toshiba e-STUDIO 3018A, Toshiba e-STUDIO 3518A, Toshiba e-STUDIO 4508LP, Toshiba e-STUDIO 4518A, Toshiba e-STUDIO 5015AC, Toshiba e-STUDIO 5018A.', '2021-12-21 04:47:14'),
(73, 'TOSHIBA Rollers 6LK42409000', 90000, 70000, 5, 0, 0, 'rollers/toshiba/6LK42409000/main.jpg', 'rollers/toshiba/6LK42409000/view1.jpg', 'rollers/toshiba/6LK42409000/view2.jpg', 2, 1, 1, 'Toshiba pressure roller idler gear /10H21 e-STUDIO 8518A it is also compatible with Toshiba e-STUDIO 5506AC, Toshiba e-STUDIO 5508A, Toshiba e-STUDIO 5516AC, Toshiba e-STUDIO 5518A, Toshiba e-STUDIO 6506AC, Toshiba e-STUDIO 6508A, Toshiba e-STUDIO 7506AC, Toshiba e-STUDIO 7508A, Toshiba e-STUDIO 7516AC, Toshiba e-STUDIO 7518A, Toshiba e-STUDIO 8508A.', 0, '2021-12-21 04:47:14', 0, '6LK42409000', 1, '', 'Toshiba pressure roller idler gear /10H21 e-STUDIO 8518A it is also compatible with Toshiba e-STUDIO 5506AC, Toshiba e-STUDIO 5508A, Toshiba e-STUDIO 5516AC, Toshiba e-STUDIO 5518A, Toshiba e-STUDIO 6506AC, Toshiba e-STUDIO 6508A, Toshiba e-STUDIO 7506AC, Toshiba e-STUDIO 7508A, Toshiba e-STUDIO 7516AC, Toshiba e-STUDIO 7518A, Toshiba e-STUDIO 8508A.', '2021-12-21 04:47:14'),
(74, 'TOSHIBA Rollers 6LK72101000', 80000, 60000, 5, 0, 0, 'rollers/toshiba/6LK72101000/main.jpg', 'rollers/toshiba/6LK72101000/view1.jpg', 'rollers/toshiba/6LK72101000/view1.jpg', 2, 1, 1, 'Genuine Toshiba lower heat roller for e-STUDIO 4518A and also fits these models: Toshiba e-STUDIO 3508A, Toshiba e-STUDIO 3518A, Toshiba e-STUDIO 4508A, Toshiba e-STUDIO 5008A, Toshiba e-STUDIO 5018A. ', 0, '2021-12-21 04:47:14', 0, '6LK72101000', 0, '', 'Genuine Toshiba lower heat roller for e-STUDIO 4518A and also fits these models: Toshiba e-STUDIO 3508A, Toshiba e-STUDIO 3518A, Toshiba e-STUDIO 4508A, Toshiba e-STUDIO 5008A, Toshiba e-STUDIO 5018A. ', '2021-12-21 04:47:14'),
(75, 'HP Fuser units P1B91A', 150000, 15000, 4, 0, 0, 'fuser_units/hp/P1B91A/main.jpg', 'fuser_units/hp/P1B91A/view1.jpg', 'fuser_units/hp/P1B91A/view2.jpg', 4, 1, 1, 'Genuine 120 Volt Fuser Unit for HP Color LaserJet Enterprise MFP M681dh and yields 150,000 estimated pages - The fusing assembly bonds toner to paper through a combination of heat and pressure includes instructions. It also works HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M653dn.', 0, '2021-12-21 05:45:12', 0, 'P1B91A', 1, '', 'Genuine 120 Volt Fuser Unit for HP Color LaserJet Enterprise MFP M681dh and yields 150,000 estimated pages - The fusing assembly bonds toner to paper through a combination of heat and pressure includes instructions. It also works HP Color LaserJet Enterprise Flow MFP M681z, HP Color LaserJet Enterprise Flow MFP M682z, HP Color Laserjet Enterprise M652dn, HP Color Laserjet Enterprise M653dn.', '2021-12-21 05:45:12'),
(76, 'HP Fuser units RM2-5177-000CN', 140000, 100000, 4, 0, 0, 'fuser_units/hp/RM2-5177-000CN/main.jpg', 'fuser_units/hp/RM2-5177-000CN/view1.jpg', 'fuser_units/hp/RM2-5177-000CN/view2.jpg', 4, 1, 1, 'Genuine fuser assembly 110/120 Volt for HP Color LaserJet Pro MFP M476dw. It works in HP Color LaserJet Pro MFP M476dn, HP Color LaserJet Pro MFP M476nw, HP LaserJet Pro 300 Color MFP M375nw, HP LaserJet Pro 400 Color M451dn, HP LaserJet Pro 400 Color M451dw, HP LaserJet Pro 400 Color M451nw.', 0, '2021-12-21 05:45:12', 0, 'RM2-5177-000CN', 0, '', 'Genuine fuser assembly 110/120 Volt for HP Color LaserJet Pro MFP M476dw. It works in HP Color LaserJet Pro MFP M476dn, HP Color LaserJet Pro MFP M476nw, HP LaserJet Pro 300 Color MFP M375nw, HP LaserJet Pro 400 Color M451dn, HP LaserJet Pro 400 Color M451dw, HP LaserJet Pro 400 Color M451nw.', '2021-12-21 05:45:12'),
(77, 'KYOCERA Fuser units FK-3100', 13000, 10000, 4, 0, 0, 'fuser_units/kyocera/FK-3100/main.jpg', 'fuser_units/kyocera/FK-3100/view2.jpg', 'fuser_units/kyocera/FK-3100/view1.jpg', 5, 1, 1, 'Genuine 120 volt Fuser (Fixing) unit for Kyocera ECOSYS M3540idn. It also fits these models: Kyocera ECOSYS M3040idn, Kyocera FS-2100DN. and yields 300000 estimated pages.', 0, '2021-12-21 06:00:26', 0, 'FK-3100', 0, '', 'Genuine 120 volt Fuser (Fixing) unit for Kyocera ECOSYS M3540idn. It also fits these models: Kyocera ECOSYS M3040idn, Kyocera FS-2100DN. and yields 300000 estimated pages.', '2021-12-21 06:00:26'),
(78, 'KYOCERA Fuser units FK-6117', 120000, 15000, 4, 0, 0, 'fuser_units/kyocera/FK-6117/main.jpg', 'fuser_units/kyocera/FK-6117/view1.jpg', 'fuser_units/kyocera/FK-6117/view2.jpg', 5, 1, 1, 'Fuser unit assembly for Kyocera ECOSYS M4132idn, ECOSYS M4028idn, ECOSYS 4028idn, ECOSYS M4125idn. It yields 300K estimated pages', 0, '2021-12-21 06:00:26', 0, 'FK-6117', 1, '', 'Fuser unit assembly for Kyocera ECOSYS M4132idn, ECOSYS M4028idn, ECOSYS 4028idn, ECOSYS M4125idn. It yields 300K estimated pages', '2021-12-21 06:00:26'),
(79, 'KYOCERA Fuser units FK-7127', 150000, 120000, 4, 0, 0, 'fuser_units/kyocera/FK-7127/main.jpg', 'fuser_units/kyocera/FK-7127/view2.jpg', 'fuser_units/kyocera/FK-7127/view2.jpg', 5, 1, 1, 'Fuser unit for Kyocera TASKalfa 3212i, Kyocera TASKalfa 3262i Kyocera TASKalfa 4012i, and Kyocera TASKalfa 4062i. It yields 300000 estimated pages.', 0, '2021-12-21 06:00:26', 0, 'FK-7127', 0, '', 'Fuser unit for Kyocera TASKalfa 3212i, Kyocera TASKalfa 3262i Kyocera TASKalfa 4012i, and Kyocera TASKalfa 4062i. It yields 300000 estimated pages.', '2021-12-21 06:00:26'),
(80, 'KYOCERA Fuser units FK-8115', 1600000, 140000, 4, 0, 0, 'fuser_units/kyocera/FK-8115/main.jpg', 'fuser_units/kyocera/FK-8115/view1.jpg', 'fuser_units/kyocera/FK-8115/view2.jpg', 5, 1, 1, 'Genuine 120 Volt Fuser Unit for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. It yields 200000 estimated pages. ', 0, '2021-12-21 06:00:26', 0, 'FK-8115', 1, '', 'Genuine 120 Volt Fuser Unit for Kyocera ECOSYS M8124cidn and Kyocera ECOSYS M8130cidn. It yields 200000 estimated pages. ', '2021-12-21 06:00:26'),
(81, 'TOSHIBA Fuser units 6AG00009220', 145000, 140000, 4, 0, 0, 'fuser_units/toshiba/6AG00009220/main.jpg', 'fuser_units/toshiba/6AG00009220/view1.jpg', 'fuser_units/toshiba/6AG00009220/view2.jpg', 2, 1, 1, 'Genuine Toshiba 120 volt Fuser Unit for e-STUDIO 400AC and also compatible with e-STUDIO 330AC.', 0, '2021-12-21 06:00:26', 0, '6AG00009220', 0, '', 'Genuine Toshiba 120 volt Fuser Unit for e-STUDIO 400AC and also compatible with e-STUDIO 330AC.', '2021-12-21 06:00:26'),
(82, 'TOSHIBA Fuser units 6LJ78113000', 90000, 85000, 4, 0, 0, 'fuser_units/toshiba/6LJ78113000/main.jpg', 'fuser_units/toshiba/6LJ78113000/view1.jpg', 'fuser_units/toshiba/6LJ78113000/view2.jpg', 2, 1, 1, 'Genuine Toshiba fuser maintenance kit for e-STUDIO 2802AF and also compatible with Toshiba e-STUDIO 2309A, Toshiba e-STUDIO 2802AM, Toshiba e-STUDIO 2803AM. The unit includes Upper Heat Roller, Lower Pressure Roller, Saw Tooth, Ozone Filter, Recovery Blade Sheet, Heat Roller Bushing, Picker Finger, Scraper.', 0, '2021-12-21 06:00:26', 0, '6LJ78113000', 1, '', 'Genuine Toshiba fuser maintenance kit for e-STUDIO 2802AF and also compatible with Toshiba e-STUDIO 2309A, Toshiba e-STUDIO 2802AM, Toshiba e-STUDIO 2803AM. The unit includes Upper Heat Roller, Lower Pressure Roller, Saw Tooth, Ozone Filter, Recovery Blade Sheet, Heat Roller Bushing, Picker Finger, Scraper.', '2021-12-21 06:00:26'),
(83, 'TOSHIBA Fuser units 6LK52418000', 190000, 150000, 4, 0, 0, 'fuser_units/toshiba/6LK52418000/main.jpg', 'fuser_units/toshiba/6LK52418000/view1.jpg', 'fuser_units/toshiba/6LK52418000/view2.jpg', 2, 1, 1, 'Genuine Toshiba fuser unit that works well with these Toshiba models: Toshiba e_STUDIO 4515AC and Toshiba e-STUDIO 5015AC. ', 0, '2021-12-21 06:00:26', 0, '6LK52418000', 0, '', 'Genuine Toshiba fuser unit that works well with these Toshiba models: Toshiba e_STUDIO 4515AC and Toshiba e-STUDIO 5015AC. ', '2021-12-21 06:00:26'),
(84, 'TOSHIBA Fuser units 6LK72103100', 180000, 150000, 4, 0, 0, 'fuser_units/toshiba/6LK72103100/main.jpg', 'fuser_units/toshiba/6LK72103100/view1.jpg', 'fuser_units/toshiba/6LK72103100/view2.jpg', 2, 1, 1, 'Genuine Toshiba fuser unit includes KitUpper Fuser Picker Finger, Ozone Filter, Upper Heat Roller, Lower Heat Roller. It works well with these Toshiba models: E STUDIO 3508A, Toshiba E STUDIO 3518A, Toshiba E STUDIO 4508A, Toshiba E STUDIO 4518A, Toshiba E STUDIO 5018A.', 0, '2021-12-21 06:00:26', 0, '6LK72103100', 1, '', 'Genuine Toshiba fuser unit includes KitUpper Fuser Picker Finger, Ozone Filter, Upper Heat Roller, Lower Heat Roller. It works well with these Toshiba models: E STUDIO 3508A, Toshiba E STUDIO 3518A, Toshiba E STUDIO 4508A, Toshiba E STUDIO 4518A, Toshiba E STUDIO 5018A.', '2021-12-21 06:00:26'),
(85, 'CANON Drum units 475C003', 250000, 20000, 2, 0, 0, 'drum_units/canon/475C003/main.jpg', 'drum_units/canon/475C003/view1.jpg', 'drum_units/canon/475C003/view2.jpg', 3, 1, 1, 'Genuine drum unit for Canon imageRUNNER ADVANCE 4535i-4525i estimated to yield 334,000 pages and 4551i-4545i estimated to yield 298,000 pages.', 0, '2021-12-21 06:25:20', 0, '475C003', 1, '', 'Genuine drum unit for Canon imageRUNNER ADVANCE 4535i-4525i estimated to yield 334,000 pages and 4551i-4545i estimated to yield 298,000 pages.', '2021-12-21 06:25:20'),
(86, 'KYOCERA Drum units DK-1185', 250000, 210000, 2, 0, 0, 'drum_units/kyocera/DK-1185/main.jpg', 'drum_units/kyocera/DK-1185/view2.jpg', 'drum_units/kyocera/DK-1185/view2.jpg', 5, 1, 1, 'Genuine drum Kit for Kyocera ECOSYS M8124cidn and ECOSYS M8130cidn yields 200000 estimated pages. ', 0, '2021-12-21 06:25:20', 0, 'DK-1185', 1, '', 'Genuine drum Kit for Kyocera ECOSYS M8124cidn and ECOSYS M8130cidn yields 200000 estimated pages. ', '2021-12-21 06:25:20'),
(87, 'KYOCERA Drum units DK-3100', 254000, 250000, 2, 0, 0, 'drum_units/kyocera/DK-3100/main.jpg', 'drum_units/kyocera/DK-3100/view1.jpg', 'drum_units/kyocera/DK-3100/view2.jpg', 5, 1, 1, 'Genuine Drum Unit for Kyocera ECOSYS M3540idn Kyocera and also fits in these models ECOSYS M3040idn, Kyocera FS-2100DN. The DK3100 laser printer image drum effortlessly and accurately offers a high yield of 300,000 pages. This helps you print consistent and crisp documents for a long time with ease. It also saves you the trouble of replacing the image drum time and again.', 0, '2021-12-21 06:25:20', 0, 'DK-3100', 0, '', 'Genuine Drum Unit for Kyocera ECOSYS M3540idn Kyocera and also fits in these models ECOSYS M3040idn, Kyocera FS-2100DN. The DK3100 laser printer image drum effortlessly and accurately offers a high yield of 300,000 pages. This helps you print consistent and crisp documents for a long time with ease. It also saves you the trouble of replacing the image drum time and again.', '2021-12-21 06:25:20'),
(88, 'KYOCERA Drum units DK-6115', 200000, 150000, 2, 0, 0, 'drum_units/kyocera/DK-6115/main.jpg', 'drum_units/kyocera/DK-6115/view1.jpg', 'drum_units/kyocera/DK-6115/view2.jpg', 5, 1, 1, 'Genuine Kyocera drum for ECOSYS M4125idn, ECOSYS M4132idn, ECOSYS M4230idn, ECOSYS M4226idn. It yields about 300000 estimated pages.', 0, '2021-12-21 06:25:20', 0, 'DK-6115', 1, '', 'Genuine Kyocera drum for ECOSYS M4125idn, ECOSYS M4132idn, ECOSYS M4230idn, ECOSYS M4226idn. It yields about 300000 estimated pages.', '2021-12-21 06:25:20'),
(89, 'KYOCERA Drum units DK-7125', 195000, 190000, 2, 0, 0, 'drum_units/kyocera/DK-7125/main.jpg', 'drum_units/kyocera/DK-7125/view1.jpg', 'drum_units/kyocera/DK-7125/view2.jpg', 0, 0, 0, 'Drum Kit DK-7125 for Kyocera Mita Taskalfa 3212i and Kyocera Mita - TASKalfa 4012i yields 600 000 estimated pages. ', 0, '2021-12-21 06:25:20', 0, 'DK-7125', 0, '', 'Drum Kit DK-7125 for Kyocera Mita Taskalfa 3212i and Kyocera Mita - TASKalfa 4012i yields 600 000 estimated pages. ', '2021-12-21 06:25:20'),
(90, 'TOSHIBA Drum units 6AG00009253', 21000, 20000, 2, 0, 0, 'drum_units/toshiba/6AG00009253/main.jpg', 'drum_units/toshiba/6AG00009253/view1.jpg', 'drum_units/toshiba/6AG00009253/view2.jpg', 2, 0, 0, 'Genuine Black Toshiba drum unit for Toshiba e-STUDIO 330AC, Toshiba e-STUDIO 400AC which includes the developer. It yields 75,000 pages @ 5%.', 0, '2021-12-21 06:25:20', 0, '6AG00009253', 0, '', 'Genuine Black Toshiba drum unit for Toshiba e-STUDIO 330AC, Toshiba e-STUDIO 400AC which includes the developer. It yields 75,000 pages @ 5%.', '2021-12-21 06:25:20'),
(91, 'TOSHIBA Drum units 6LJ83358000', 1460000, 1400000, 2, 0, 0, 'drum_units/toshiba/6LJ83358000/main.jpg', 'drum_units/toshiba/6LJ83358000/view1.jpg', 'drum_units/toshiba/6LJ83358000/view2.jpg', 2, 1, 1, 'The drum kit is compatible with these Toshiba machine models:e_STUDIO 2802AF, 2802AM, 2822AF, 2309A, 2809A. It yields Approximately 55,000 pages based on the industry standards.', 0, '2021-12-21 06:25:20', 0, '6LJ83358000', 1, '', 'The drum kit is compatible with these Toshiba machine models:e_STUDIO 2802AF, 2802AM, 2822AF, 2309A, 2809A. It yields Approximately 55,000 pages based on the industry standards.', '2021-12-21 06:25:20'),
(92, 'TOSHIBA Drum units 6LK40607000', 1500000, 1400000, 2, 0, 0, 'drum_units/toshiba/6LK40607000/main.jpg', 'drum_units/toshiba/6LK40607000/view1.jpg', 'drum_units/toshiba/6LK40607000/view2.jpg', 2, 1, 1, 'This Toshiba drum unit is also executable in these models e-STUDIO 5018A, 5506AC, 5508A, 6506AC, 6508A, 7506AC, 7508A, 7516AC, 7518A, 8508A, 8508AG. It yields maximum standard of 480,000 Pages', 0, '2021-12-21 06:25:20', 0, '6LK40607000', 0, '', 'This Toshiba drum unit is also executable in these models e-STUDIO 5018A, 5506AC, 5508A, 6506AC, 6508A, 7506AC, 7508A, 7516AC, 7518A, 8508A, 8508AG. It yields maximum standard of 480,000 Pages', '2021-12-21 06:25:20'),
(93, 'TOSHIBA Drum units 6LK49015000', 152000, 1500000, 2, 0, 0, 'drum_units/toshiba/6LK49015000/main.jpg', 'drum_units/toshiba/6LK49015000/view2.jpg', 'drum_units/toshiba/6LK49015000/view2.jpg', 2, 1, 1, 'This drum unit is guaranteed by the manufacturer to generate optimum print quality and give you maximum productivity. It yields approximately 80,000 pages and fits in these Toshiba models e-STUDIO 2518A, 3018A, 3518A, 5018A. ', 0, '2021-12-21 06:25:20', 0, '6LK49015000', 1, '', 'This drum unit is guaranteed by the manufacturer to generate optimum print quality and give you maximum productivity. It yields approximately 80,000 pages and fits in these Toshiba models e-STUDIO 2518A, 3018A, 3518A, 5018A. ', '2021-12-21 06:25:20'),
(94, 'TOSHIBA Drum units 6LK49103000', 132000, 130000, 2, 0, 0, 'drum_units/toshiba/6LK49103000/main.jpg', 'drum_units/toshiba/6LK49103000/view1.jpg', 'drum_units/toshiba/6LK49103000/view2.jpg', 2, 1, 1, 'Toshiba drum unit which includes cleaning unit. It works well with these models e_STUDIO 2010AC, 2510AC 2000AC, 2050C, 2051C, 2550C, 2551C', 0, '2021-12-21 06:25:20', 0, '6LK49103000', 0, '', 'Toshiba drum unit which includes cleaning unit. It works well with these models e_STUDIO 2010AC, 2510AC 2000AC, 2050C, 2051C, 2550C, 2551C', '2021-12-21 06:25:20'),
(95, 'TOSHIBA Drum units 6LK67102300', 175000, 170000, 2, 0, 0, 'drum_units/toshiba/6LK67102300/main.jpg', 'drum_units/toshiba/6LK67102300/view1.jpg', 'drum_units/toshiba/6LK67102300/view2.jpg', 2, 1, 1, 'Compatible drum unit for Toshiba models : E STUDIO 2518A, Toshiba E STUDIO 3018A, Toshiba E STUDIO 3518A, Toshiba E STUDIO 4518A, Toshiba E STUDIO 5018A.', 0, '2021-12-21 06:25:20', 0, '6LK67102300', 1, '', 'Compatible drum unit for Toshiba models : E STUDIO 2518A, Toshiba E STUDIO 3018A, Toshiba E STUDIO 3518A, Toshiba E STUDIO 4518A, Toshiba E STUDIO 5018A.', '2021-12-21 06:25:20');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_promotions`
--

CREATE TABLE `ecom_promotions` (
  `promotion_id` int(11) NOT NULL,
  `promotion_name` varchar(120) NOT NULL,
  `offer` int(11) NOT NULL,
  `promotion_date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecom_shipping_details`
--

CREATE TABLE `ecom_shipping_details` (
  `shipping_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_details` text NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone` varchar(120) NOT NULL,
  `address1` varchar(120) NOT NULL,
  `address2` varchar(120) NOT NULL,
  `city` varchar(120) NOT NULL,
  `fname` varchar(120) NOT NULL,
  `lname` varchar(120) NOT NULL,
  `country` varchar(120) NOT NULL,
  `amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_shipping_details`
--

INSERT INTO `ecom_shipping_details` (`shipping_id`, `customer_id`, `shipping_details`, `email`, `phone`, `address1`, `address2`, `city`, `fname`, `lname`, `country`, `amount`) VALUES
(1, 12, '0', 'mutalejether@gmail.com', '0784440934', 'kira', '0', 'kira', 'magar', 'jery', 'cont', 0),
(2, 13, '0', 'mutalejether@gmail.com', '0784440934', 'kira', '0', 'kira', 'mutale', 'john', 'cont', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ecom_stores`
--

CREATE TABLE `ecom_stores` (
  `store_id` int(11) NOT NULL,
  `store_name` varchar(120) NOT NULL,
  `store_location` varchar(120) NOT NULL,
  `store_image` varchar(120) NOT NULL,
  `store_desc` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_stores`
--

INSERT INTO `ecom_stores` (`store_id`, `store_name`, `store_location`, `store_image`, `store_desc`, `date_created`) VALUES
(1, 'Main Go-Down', 'Main Branch', '', '', '2021-12-20 15:39:28');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_sub_category`
--

CREATE TABLE `ecom_sub_category` (
  `sub_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_name` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_sub_category`
--

INSERT INTO `ecom_sub_category` (`sub_id`, `category_id`, `sub_name`, `date_created`) VALUES
(1, 1, 'Black and White', '2021-12-06 12:04:11'),
(2, 1, 'Coloured - Yellow', '2021-12-06 12:17:01'),
(3, 1, 'Coloured - Magenta', '2021-12-07 11:04:28'),
(4, 1, 'Coloured - Cyan', '2021-12-20 15:34:37');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_testimonials`
--

CREATE TABLE `ecom_testimonials` (
  `id` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `names` varchar(120) NOT NULL,
  `organization` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `favourite`
--

CREATE TABLE `favourite` (
  `fav_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `regular_price` double NOT NULL,
  `sale_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer`
--

CREATE TABLE `manufacturer` (
  `manufacturer_id` int(11) NOT NULL,
  `manufacturer_name` varchar(120) NOT NULL,
  `manufacturer_logo` varchar(120) NOT NULL,
  `manufacturer_location` varchar(120) NOT NULL,
  `manufacturer_desc` text NOT NULL,
  `manufacturer_date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manufacturer`
--

INSERT INTO `manufacturer` (`manufacturer_id`, `manufacturer_name`, `manufacturer_logo`, `manufacturer_location`, `manufacturer_desc`, `manufacturer_date_created`) VALUES
(2, 'Toshiba', 'toshiba_logo.png', '', '', '2021-12-20 15:37:20'),
(3, 'Canon', 'canon_logo.png', '', '', '2021-12-20 15:37:20'),
(4, 'HP', 'hp_logo1.png', '', '', '2021-12-20 15:38:17'),
(5, 'Kyocera', 'kyocera_logo.png', '', '', '2021-12-20 15:38:17');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer_model`
--

CREATE TABLE `manufacturer_model` (
  `model_id` int(11) NOT NULL,
  `model_name` varchar(120) NOT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `noti_id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `body` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(22) NOT NULL,
  `status` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`noti_id`, `title`, `body`, `user_id`, `status`, `date`) VALUES
(1, 'ORDERID:D890658199', 'Your Order D890658199 is Confirmed', 12, 0, '2023-05-10 14:29:03'),
(2, 'ORDERID:Y739721643', 'Your Order Y739721643 is Confirmed', 12, 0, '2023-05-10 14:30:04'),
(3, 'ORDERID:Y739721643', 'Your Order Y739721643 is Confirmed', 12, 0, '2023-05-10 14:30:23'),
(4, 'ORDERID:Y739721643', 'Your Order Y739721643 is Confirmed', 12, 0, '2023-05-11 13:20:12'),
(5, 'ORDERID:Y739721643', 'Your Order Y739721643 is Confirmed', 12, 0, '2023-05-11 13:20:26'),
(6, 'ORDERID:Y739721643', 'Your Order Y739721643 is Confirmed', 12, 0, '2023-05-11 13:20:47'),
(7, 'ORDERID:Y739721643', 'Your Order Y739721643 is Confirmed', 12, 0, '2023-05-11 13:20:51'),
(8, 'ORDERID:T985178343', 'Your Order T985178343 is Confirmed', 13, 1, '2023-05-12 06:10:35'),
(9, 'ORDERID:T985178343', 'Your Order T985178343 is Canceled', 13, 1, '2023-05-12 06:11:04'),
(10, 'ORDERID:T985178343', 'Your Order T985178343 is Canceled', 13, 0, '2023-05-12 06:11:18'),
(11, 'ORDERID:T985178343', 'Your Order T985178343 is Canceled', 13, 0, '2023-05-12 06:11:40');

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `logo` varchar(120) NOT NULL,
  `names` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `logo`, `names`) VALUES
(1, 'adventure_vacation_safaris.png', 'Adventure Vacation Safaris'),
(2, 'bird_outfits_logo.png', 'Bird Outfits'),
(3, 'tamani_africa_logo.png', 'Tamani Africa Limited'),
(4, 'toplife_logo.jpg', 'TopLife Safaris'),
(5, 'uap.png', 'Uganda Association Of Physio-therapists'),
(6, 'wunderbar_africa_safaris.png', 'Wunderbar Africa Safaris'),
(7, 'zaabu_logo.png', 'Zaabu Trails Tours & Travels');

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `method_id` int(11) NOT NULL,
  `method_name` varchar(120) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `logo` varchar(120) NOT NULL,
  `code` varchar(120) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`method_id`, `method_name`, `date_created`, `logo`, `code`, `description`) VALUES
(1, 'Using Mobile Money Merchant Codes', '2021-12-13 15:41:25', 'airel_mtn.png', '', 'Available for Uganda Only (Airtel / MTN                                                                     )'),
(2, 'Using Flutter Wave Payments', '2021-12-13 15:41:25', 'flutter_wave_logo.png', '', 'Supports all forms of Online                                                                 transactions'),
(3, 'Pay with Cash On Delivery', '2021-12-13 20:32:43', 'cod.png', '', 'Available Internationally');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `email1` varchar(120) NOT NULL,
  `email2` varchar(120) NOT NULL,
  `location` varchar(120) NOT NULL,
  `contact` varchar(120) NOT NULL,
  `fax` varchar(120) NOT NULL,
  `facebook` varchar(120) NOT NULL,
  `twitter` varchar(120) NOT NULL,
  `instagram` varchar(120) NOT NULL,
  `youtube` varchar(120) NOT NULL,
  `googlemaps` varchar(120) NOT NULL,
  `country` varchar(120) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `email1`, `email2`, `location`, `contact`, `fax`, `facebook`, `twitter`, `instagram`, `youtube`, `googlemaps`, `country`, `address`) VALUES
(1, 'info@edgetechuganda.com', 'sales@edgetechuganda.com', 'Plot 69 Kyadondo Rd', '', ' 0800 280 040', '', '', '', '', '', 'Uganda', 'Plot 69 Kyadondo Rd , Uganda');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_category`
--
ALTER TABLE `ecom_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ecom_customer`
--
ALTER TABLE `ecom_customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `ecom_favorite`
--
ALTER TABLE `ecom_favorite`
  ADD PRIMARY KEY (`fav_id`);

--
-- Indexes for table `ecom_order`
--
ALTER TABLE `ecom_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `ecom_order_items`
--
ALTER TABLE `ecom_order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_product`
--
ALTER TABLE `ecom_product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `ecom_promotions`
--
ALTER TABLE `ecom_promotions`
  ADD PRIMARY KEY (`promotion_id`);

--
-- Indexes for table `ecom_shipping_details`
--
ALTER TABLE `ecom_shipping_details`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `ecom_stores`
--
ALTER TABLE `ecom_stores`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `ecom_sub_category`
--
ALTER TABLE `ecom_sub_category`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `ecom_testimonials`
--
ALTER TABLE `ecom_testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favourite`
--
ALTER TABLE `favourite`
  ADD PRIMARY KEY (`fav_id`);

--
-- Indexes for table `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- Indexes for table `manufacturer_model`
--
ALTER TABLE `manufacturer_model`
  ADD PRIMARY KEY (`model_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`noti_id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`method_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_category`
--
ALTER TABLE `ecom_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ecom_customer`
--
ALTER TABLE `ecom_customer`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ecom_favorite`
--
ALTER TABLE `ecom_favorite`
  MODIFY `fav_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ecom_order`
--
ALTER TABLE `ecom_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ecom_order_items`
--
ALTER TABLE `ecom_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `ecom_product`
--
ALTER TABLE `ecom_product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `ecom_promotions`
--
ALTER TABLE `ecom_promotions`
  MODIFY `promotion_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_shipping_details`
--
ALTER TABLE `ecom_shipping_details`
  MODIFY `shipping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ecom_stores`
--
ALTER TABLE `ecom_stores`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ecom_sub_category`
--
ALTER TABLE `ecom_sub_category`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ecom_testimonials`
--
ALTER TABLE `ecom_testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `favourite`
--
ALTER TABLE `favourite`
  MODIFY `fav_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manufacturer`
--
ALTER TABLE `manufacturer`
  MODIFY `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `manufacturer_model`
--
ALTER TABLE `manufacturer_model`
  MODIFY `model_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `noti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
