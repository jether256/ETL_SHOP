<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){ 
    return openssl_decrypt($text, method, key, 0, iv);
}


$search = mysqli_real_escape_string($con,decryp($_POST['search']));


//$search=mysqli_real_escape_string($con,$_POST['search']);

$list=array();
$po="SELECT * FROM ecom_product WHERE pname LIKE '%$search%' OR psale_price LIKE '%$search%' OR model_id LIKE '%$search%' OR psdescription LIKE '%$search%'";
$chato=mysqli_query($con,$po);

if($chato){

        while($row=$chato->fetch_assoc()){
            $list[]=$row;

        }

        echo json_encode($list);

}


?>