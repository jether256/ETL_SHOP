<?php
header("Access-Control-Allow-Origin: *");

include('dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}

$meid= mysqli_real_escape_string($con,decryp($_POST['me_id']));
$bizid = mysqli_real_escape_string($con,decryp($_POST['user_id']));
$qty = mysqli_real_escape_string($con,decryp($_POST['qty']));
$pr = mysqli_real_escape_string($con,decryp($_POST['price']));
$com = mysqli_real_escape_string($con,decryp($_POST['compared']));
$pro = mysqli_real_escape_string($con,decryp($_POST['product']));
$pro_id = mysqli_real_escape_string($con,decryp($_POST['pro_id']));
$wei = mysqli_real_escape_string($con,decryp($_POST['weight']));
$im = mysqli_real_escape_string($con,decryp($_POST['image']));
$tot = mysqli_real_escape_string($con,decryp($_POST['total']));
$shop = mysqli_real_escape_string($con,decryp($_POST['shop']));

$user="select * from cart where me_id='$meid' AND pro_id='$pro_id' ";
$run_user=mysqli_query($con,$user);
$userData=array();
$userDa=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){
    
     echo json_encode("Already");


}else{

   $insert="insert into cart (me_id,user_id,qty,price,compared,product,pro_id,weight,image,total,shop) 
      values('$meid','$bizid','$qty','$pr','$com','$pro','$pro_id','$wei','$im','$tot','$shop')";
      $real=mysqli_query($con,$insert);
   if($real){

    
      $sql="select * from cart where me_id='$meid' AND pro_id='$pro_id' ";
      $query=mysqli_query($con,$sql);
      $data=mysqli_fetch_array($query);
      $userData=$data;

   }

   echo json_encode($userData);

}

?>