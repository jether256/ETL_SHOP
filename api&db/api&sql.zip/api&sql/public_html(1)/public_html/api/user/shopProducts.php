<?php
require('dbconnection.php');

$uid=$_POST['user_id'];
 $ser=$_POST['title'];

$list=array();
$po="select * from proserve where user_id='$uid' AND category='$ser' ";
$run_posts=mysqli_query($con,$po);

if($run_posts){

        while($row=$run_posts->fetch_assoc()){
            $list[]=$row;

        }

        echo json_encode($list);

}

?>