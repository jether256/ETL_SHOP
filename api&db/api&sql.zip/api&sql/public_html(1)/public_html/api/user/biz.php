<?php
include('dbconnection.php');


//$uid=$_POST['user_id'];


$list=array();
$po="select * from business where user_id='4' ";
$run_posts=mysqli_query($con,$po);

if($run_posts){

        while($row=$run_posts->fetch_assoc()){
            $list[]=$row;

        }

        echo json_encode($list);

}

?>