<?php

header("Access-Control-Allow-Origin: *");


include('dbconnection.php');


const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$doci = mysqli_real_escape_string($con,decryp($_POST['doc_id']));
$docnem = mysqli_real_escape_string($con,decryp($_POST['docnem']));
$puid = mysqli_real_escape_string($con,decryp($_POST['puid']));
$pnem = mysqli_real_escape_string($con,decryp($_POST['pname']));
$ag = mysqli_real_escape_string($con,decryp($_POST['age']));
$pmai = mysqli_real_escape_string($con,decryp($_POST['pmail']));
$gen = mysqli_real_escape_string($con,decryp($_POST['gender']));
$ser = mysqli_real_escape_string($con,decryp($_POST['service']));
$pPhn = mysqli_real_escape_string($con,decryp($_POST['pPhone']));
$lati = mysqli_real_escape_string($con,decryp($_POST['lat']));
$loni = mysqli_real_escape_string($con,decryp($_POST['lon']));
$des = mysqli_real_escape_string($con,decryp($_POST['desc']));
$amt = mysqli_real_escape_string($con,decryp($_POST['amount']));
$apSta = mysqli_real_escape_string($con,decryp($_POST['appstatus']));
$pSt = mysqli_real_escape_string($con,decryp($_POST['paymentStatus']));
$pDay = mysqli_real_escape_string($con,decryp($_POST['paymentDate']));
$pMod = mysqli_real_escape_string($con,decryp($_POST['paymentMode']));
$stat = mysqli_real_escape_string($con,decryp($_POST['startTime']));
$end = mysqli_real_escape_string($con,decryp($_POST['endTime']));
$on = mysqli_real_escape_string($con,decryp($_POST['online']));


  $createdTimeStamp = date("Y-m-d H:i:s");  
  $updatedTimeStamp = date("Y-m-d H:i:s"); 

$rand =rand(10000,10000000000);
 
//AND end_time='$end'

// SELECT *  FROM `department` where `name`='$name' AND `isDeleted`=false AND `clinic_id`='$clinicId' AND `city_id`='$cityId'

$user="SELECT *  FROM `appointment` where `doc_id`='$doci' AND `paymentDate`='$pDay' AND `start_time`='$stat' AND `end_time`='$end' ";
// $user="select * from  appointment where doc_id='$doci' AND paymentDate='$pDay' AND  startTime='$stat' ";

$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){

 echo json_encode("ERROR");

}else{

   $insert="insert into  appointment(order_id,doc_id,cli_id,host_id,dept_id,docnem,dept,puid,pname,age,servicenem,pEmail,gmeetLink,createdTimeStamp,updatedTimeStamp,serviceTimeMin,pPhone,lat,lon,   description,searchByName,amount,paymentStatus,paymentDate,paymentMode,start_time,end_time,   isOnline)
    values('$rand','$doci','0','0','0','$docnem','0','$puid','$pnem','$ag','$ser','$pmai','0',' $createdTimeStamp',' $updatedTimeStamp','0','$pPhn','$lati','$loni','$des','$apSta','$amt','$pSt','$pDay','$pMod','$stat','$end','$on')";
   $res=mysqli_query($con,$insert);
   if($res){

    
      $sql="select * from appointment where puid='$puid' ";
      $query=mysqli_query($con,$sql);
      $data=mysqli_fetch_array($query);
      $userData=$data;

   }

   echo json_encode($userData);

}
?>