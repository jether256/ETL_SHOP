<?php
include('dbconnection.php');

$id = $_POST['ID'];


$del="delete from  cart where ID = '$id' ";

$run_location=mysqli_query($con,$del);

if($run_location){


   
    json_encode("yeah");

    }else{
         json_encode("no");

    }




?>