<?php

header("Access-Control-Allow-Origin: *");


include('dbconnection.php');


const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$cno = mysqli_real_escape_string($con,decryp($_POST['cardNumber']));
$exp= mysqli_real_escape_string($con,decryp($_POST['expiryDate']));
$nem = mysqli_real_escape_string($con,decryp($_POST['cardHolderName']));
$code = mysqli_real_escape_string($con,decryp($_POST['cvvCode']));
$show = mysqli_real_escape_string($con,decryp($_POST['showBackView']));
$uid = mysqli_real_escape_string($con,decryp($_POST['uid']));


$user="select * from cards where uid='$uid' AND cno='$cno' ";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){

 echo json_encode("ERROR");

}else{

   $insert="insert into cards(name,cno,cvvcode,expiry,showback,uid)
    values('$nem','$cno','$code','$exp','$show','$uid')";
   $res=mysqli_query($con,$insert);
   if($res){

    
      $sql="select * from cards where uid='$uid' AND cno='$cno' ";
      $query=mysqli_query($con,$sql);
      $data=mysqli_fetch_array($query);
      $userData=$data;

   }

   echo json_encode($userData);

}
?>