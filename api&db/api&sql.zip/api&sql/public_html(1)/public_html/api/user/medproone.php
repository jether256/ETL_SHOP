<?php
include('dbconnection.php');


$cat=$_POST['category'];
$uid=$_POST['user_id'];

$list=array();
$po="select * from proserve where category='$cat' and user_id='$uid'";
$run_posts=mysqli_query($con,$po);

if($run_posts){

        while($row=$run_posts->fetch_assoc()){
            $list[]=$row;

        }

        echo json_encode($list);

}

?>