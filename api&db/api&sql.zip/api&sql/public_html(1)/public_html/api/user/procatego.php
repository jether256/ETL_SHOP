<?php 

header("Access-Control-Allow-Origin: *");

include('dbconnection.php');

    $response = array();

    // $cek_category = mysqli_query($connection, "SELECT * FROM category_product WHERE status ='on'");


        $check_cat="select * from medcat where ono='on'";
        $run_cat=mysqli_query($con,$check_cat);

    while ($row_category = mysqli_fetch_array($run_cat)) {
        # code...
        // $id_category = $row_category['ID'];
        // $key['ID'] = $id_category;
        $key['ID'] = $row_category['ID'];
        $categ = $row_category['category'];
        $key['category'] = $categ;
        //$key['category'] = $row_category['category'];
        $key['image'] = $row_category['image'];
        $key['ono'] = $row_category['ono'];

        $key['product'] = array();

        // $cek_product = mysqli_query($connection, "SELECT * FROM product WHERE id_category = '$id_category'");

        $check_pro="select * from proserve where category='$categ'";
        $run_pro=mysqli_query($con,$check_pro);

        while ($row_product = mysqli_fetch_array($run_pro)) {
            # code...
            $key['product'][] = array(
                'id' => $row_product['id'],
                'user_id' => $row_product['user_id'],
                'ownerName' => $row_product['ownerName'],
                'shopName' => $row_product['shopName'],
                'descc' => $row_product['descc'],
                'price' => $row_product['price'],
                'compared' => $row_product['compared'],
                'collection' => $row_product['collection'],
                'brand' => $row_product['brand'],
                'category' => $row_product['category'],
                'weight' => $row_product['weight'],
                'tax' => $row_product['tax'],
                'published' => $row_product['published'],
                'carType' => $row_product['carType'],
                'service' => $row_product['service'],
                'pack' => $row_product['pack'],
                'image' => $row_product['image'],
                'pro_id' => $row_product['pro_id'],
            );
        }

        array_push($response, $key);
    }
echo json_encode($response);

?>