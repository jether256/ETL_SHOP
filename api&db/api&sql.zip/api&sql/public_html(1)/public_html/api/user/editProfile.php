<?php
include('dbconnection.php');

$id = $_POST['id'];
$nem = $_POST['name'];
$mail = $_POST['email'];
$cont = $_POST['num'];





$lo="update users set name='$nem',email='$mail' ,number='$cont' where id = '$id' ";

$run_location=mysqli_query($con,$lo);

if($run_location){


   
    json_encode("yeah");

    }else{
         json_encode("no");

    }




?>