<?php
include('dbconnection.php');

$id = $_POST['ID'];
$qty = $_POST['qty'];
$total = $_POST['total'];





$lo="update cart set qty='$qty', total='$total', where ID = '$id' ";

$run_location=mysqli_query($con,$lo);

if($run_location){


   
    json_encode("yeah");

    }else{
         json_encode("no");

    }




?>