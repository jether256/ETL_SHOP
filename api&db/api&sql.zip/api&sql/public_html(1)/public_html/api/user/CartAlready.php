<?php
include('dbconnection.php');


$meid= mysqli_real_escape_string($con,$_POST['me_id']);
$pro_id = mysqli_real_escape_string($con,$_POST['pro_id']);

$user="select * from cart where me_id='$meid' AND pro_id='$pro_id' ";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){
    
    
     $sql="select * from cart where pro_id='$pro_id' AND  me_id='$meid'";
     $query=mysqli_query($con,$sql);
     $data=mysqli_fetch_array($query);
     $userData=$data;
     
     echo json_encode($userData);
}

?>