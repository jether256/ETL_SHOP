<?php
include('dbconnection.php');

$meid= mysqli_real_escape_string($con,$_POST['mid']);
$menem= mysqli_real_escape_string($con,$_POST['mnem']);
$mephon = mysqli_real_escape_string($con,$_POST['mphon']);
$memail = mysqli_real_escape_string($con,$_POST['mmail']);
$meadd = mysqli_real_escape_string($con,$_POST['mdress']);
$bizid = mysqli_real_escape_string($con,$_POST['user_id']);
$bnem = mysqli_real_escape_string($con,$_POST['bizname']);
$badd = mysqli_real_escape_string($con,$_POST['bizdress']);
$bphon = mysqli_real_escape_string($con,$_POST['bizphon']);
$bmail = mysqli_real_escape_string($con,$_POST['bizmail']);
// $ = mysqli_real_escape_string($con,$_POST['package']);
$ser = mysqli_real_escape_string($con,$_POST['service']);
$car = mysqli_real_escape_string($con,$_POST['carType']);
$pr = mysqli_real_escape_string($con,$_POST['price']);
$boo = mysqli_real_escape_string($con,$_POST['booking']);
$date = mysqli_real_escape_string($con,$_POST['date']);
$time = mysqli_real_escape_string($con,$_POST['time']);
$real = mysqli_real_escape_string($con,$_POST['real_date']);


$path =rand(10000,10000000000);




		$insert_team="insert into bookorder (mid,mnem,mphon,mmail,mdress,user_id,bizname,bizdress,bizphon,bizmail,package,service,carType,price,booking,date,time,order_id,total,dis,disco,delFee,productName,weight,cod,online,airtel,mtn,dbnem,dbphon,dbloco,dblon,dblat,abadd,real_date) 
		values('$meid','$menem','$mephon','$memail','$meadd','$bizid','$bnem','$badd','$bphon','$bmail','No','$ser','$car','$pr','$boo','$date','$time','$path','No','No','No','No','No','No','Yes','No','No','No','No','No','No','No','No','No','$real')";
		$run_team=mysqli_query($con,$insert_team);


		if($run_team){

			

		}


?>