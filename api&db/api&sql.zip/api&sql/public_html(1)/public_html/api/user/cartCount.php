<?php
include('dbconnection.php');

 $id = $_POST['me_id'];
  $u = $_POST['user_id'];

$query="SELECT ID FROM cart WHERE me_id='$id' AND user_id='$u' ";
$query_run=mysqli_query($con,$query);
$row=mysqli_num_rows($query_run);

echo json_encode($row);


?>