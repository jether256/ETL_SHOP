<?php

header("Access-Control-Allow-Origin: *");
include('../dbconnection.php');





const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){ 
    return openssl_decrypt($text, method, key, 0, iv);
}


$fnem = mysqli_real_escape_string($con,decryp($_POST['fname']));
$lnem = mysqli_real_escape_string($con,decryp($_POST['lname']));
$num = mysqli_real_escape_string($con,decryp($_POST['phone']));
$cont = mysqli_real_escape_string($con,decryp($_POST['count']));
$add = mysqli_real_escape_string($con,decryp($_POST['add']));
$mail = mysqli_real_escape_string($con,decryp($_POST['ema']));


// $fnem=$_POST['fname'];
// $lnem=$_POST['lname'];
// $num=$_POST['phone'];
// $cont=$_POST['count'];
// $add=$_POST['add'];
// $mail=$_POST['ema'];
// $pass=$_POST['pass'];


//$v_code=bin2hex(random_bytes(16));
$pass = mysqli_real_escape_string($con,decryp($_POST['pass']));
//$pass=password_hash($pass,PASSWORD_BCRPYT);
$pass=hash('sha256',$pass);
$photo = "";
$v_code=rand(10000,99999);

$user="select * from ecom_customer where cust_email='$mail' AND cust_password='$pass' ";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){

 echo json_encode("ERROR");

}else{

     $insert="insert into  ecom_customer(cust_fname,cust_lname,cust_email,cust_phone,cust_location,cust_photo,cust_password,cust_country,cust_created_on,veri_code,status)
     values('$fnem','$lnem','$mail','$num','$add','$photo','$pass','$cont',Now(),'$v_code','waitverification')";
     $res=mysqli_query($con,$insert);
     if($res){



        echo json_encode("REG");
        sendEmail($v_code,$mail);

     }


}



function sendEmail($v_code,$mail){

$to=$mail;
$title="Edge Shop Email Verification Code";
$body="Verification Code     $v_code";
$header="From:mutalejether@eazyrent256.com" ."\r\n";

mail($to,$title,$body,$header);

}


?>