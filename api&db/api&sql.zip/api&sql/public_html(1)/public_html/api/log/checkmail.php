<?php

header("Access-Control-Allow-Origin: *");
include('../dbconnection.php');





const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){ 
    return openssl_decrypt($text, method, key, 0, iv);
}


$mail = mysqli_real_escape_string($con,decryp($_POST['mail']));



//$mail=$_POST['mail'];


$v_code=rand(10000,99999);

$user="select * from ecom_customer where cust_email='$mail'";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){


$update = mysqli_query($con,"UPDATE ecom_customer SET veri_code = '$v_code' WHERE cust_email = '$mail'");

if($update){

    echo json_encode("Ye");

    sendEmail($v_code,$mail);


}else{

    echo json_encode("Fail");
}



}else{

     echo json_encode("No");
}


function sendEmail($v_code,$mail){

$to=$mail;
$title="Edge Shop Email Verification Code";
$body="Verification Code     $v_code";
$header="From:mutalejether@eazyrent256.com" ."\r\n";

mail($to,$title,$body,$header);

}


?>