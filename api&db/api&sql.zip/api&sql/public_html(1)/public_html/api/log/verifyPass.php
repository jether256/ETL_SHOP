<?php
 

 header("Access-Control-Allow-Origin: *");


include('../dbconnection.php');

const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){

   return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){ 
     return openssl_decrypt($text, method, key, 0, iv);
}


    $email= mysqli_real_escape_string($con,decryp($_POST['email']));
    $otp = mysqli_real_escape_string($con,decryp($_POST['key']));
   
    $sql = "SELECT * FROM ecom_customer WHERE cust_email = '$email' AND veri_code='$otp'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        
        echo json_encode("ye"); 
    }else{
        echo json_encode("no");
    }
    
    
?>