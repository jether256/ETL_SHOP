<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$mail = mysqli_real_escape_string($con,decryp($_POST['mail']));
$pass = mysqli_real_escape_string($con,decryp($_POST['pass']));
$pass=hash('sha256',$pass);



$user="update  ecom_customer set  cust_password='$pass' where cust_email='$mail' ";
$run_user=mysqli_query($con,$user);

if($run_user){

    echo	json_encode('Yes');
}else{
    
   echo	json_encode('No'); 
}



?>