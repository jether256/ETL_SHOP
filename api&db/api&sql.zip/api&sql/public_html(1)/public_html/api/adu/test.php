<?php
header("Access-Control-Allow-Origin: *");

$notAuth="";

include('../dbconnection.php');

//sendNotification("hi","How are u jether","users","","");



// $tit= $_POST['title'];
// $mess= $_POST['mess'];
// $topic= $_POST['topic'];
// $pageId= $_POST['id'];
// $pageName= $_POST['nem'];


sendGCM("hi","jether sends notifications","users12","10","masavu");




function sendGCM($tit, $mess, $topic, $pageId, $pageName)

{





    $url = 'https://fcm.googleapis.com/fcm/send';



    $fields = array(

        "to" => '/topics/' . $topic,

        'priority' => 'high',

        'content_available' => true,



        'notification' => array(

            "body" =>  $mess,

            "title" =>  $tit,

            "click_action" => "FLUTTER_NOTIFICATION_CLICK",

            "sound" => "default"



        ),

        'data' => array(

            "pageid" => $pageId,

            "pagename" => $pageName

        )



    );





    $fields = json_encode($fields);

    $headers = array(

        'Authorization: key=' . "AAAAqub6EQE:APA91bF1yf67oXVnPfUOIKQAsl_Po4lo7KCrtWcGYFMHtlK6UlUZCM2NLFPRSGAeHxBW-g99oecUL-byYwapzdmF1caHKRqeztq81YdNgG4rKCgj5uPBNskS6-NaTvjD3qMMvDCBeJK6",

        'Content-Type: application/json'

    );



    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);



    $result = curl_exec($ch);

    return $result;

    curl_close($ch);

}

echo "notAuth";

?>