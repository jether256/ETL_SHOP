<?php




function sendNotification($tit,$mess,$topic,$pageId,$pageName){

    $url ="https://fcm.googleapis.com/fcm/send";

    $fields=array(

        "to" => '/topics/'.$topic,
        'priority'=>'high',
        'content_available' => true,

        'notification'=>array(
            "body"=>$mess,
            "title"=>$tit,
            "click_action" => "FLUTTER_NOTIFICATION_CLICK",
            "sound"=>"default"
        ),

        'data'> array(
            "pageId" =>$pageId,
            "pageName" =>$pageName
        )
    );

    $fields=json_encode($fields);

    $headers=array(
        'Authorization: key=AAAAQmk5h40:APA91bF17tx7vk1n_1tYV9TUgfYhMQrg-8L1GYtw4BcCw0iF5wnruCyhRyeU3EHWQBVF1-bRxIOQ4OqgGNq_uIHkzlfITQMulzxUzsOoNziM4zeruBe284H-sWWhJ4m_Pg3wj7q9xa6H',
        'Content-Type:application/json'
    );

    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_POST,true);
    curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($fields));
    $result=curl_exec($ch);
    print_r($result);
    curl_close($ch);
}





?>