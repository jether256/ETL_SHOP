<?php
$db_name="id20184901_etl";
$db_user="id20184901_etl_user";
$db_pass="_>#e963/Z\<um9M0";
$db_host="localhost";


$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);

if(!$con){
	
	echo "connection error";
}else{
	//echo "connection successful...";
}


?>