<?php




header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$id = mysqli_real_escape_string($con,decryp($_POST['id']));

$response = array();

//$id = $_POST['id'];

$selectCart = mysqli_query($con, "SELECT * From ecom_order WHERE customer_id = '$id' order by order_id desc");

while ($row = mysqli_fetch_array($selectCart)) {
   
   $response[]=$row;
}

echo json_encode($response);

?>