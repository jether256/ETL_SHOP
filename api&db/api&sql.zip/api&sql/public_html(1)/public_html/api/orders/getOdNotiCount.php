<?php
 header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');


const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}




     $id = mysqli_real_escape_string($con,decryp($_POST['id']));

    //  $id=$_POST['id'];
   

    
    // $res=array();
    $query = mysqli_query($con, "SELECT * FROM notifications WHERE user_id = '$id'AND status='0'");
     $rowcount=mysqli_num_rows($query);
    
    echo json_encode($rowcount);
   
?>