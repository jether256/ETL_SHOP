<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


 $id = mysqli_real_escape_string($con,decryp($_POST['trans']));

//$id=$_POST['id'];

$response=array();
$sel=mysqli_query($con, "SELECT ecom_order_items.*, ecom_product.pname,ecom_product.pimage1 FROM ecom_order_items JOIN ecom_product on 
    ecom_order_items.product_id = ecom_product.pid WHERE ecom_order_items.order_id = '$id'");
while ($row=mysqli_fetch_array($sel)) {

$response[]=$row;

}

echo json_encode($response);






?>