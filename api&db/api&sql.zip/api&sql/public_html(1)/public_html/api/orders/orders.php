<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


 $id = mysqli_real_escape_string($con,decryp($_POST['id']));

//$id=$_POST['id'];

$response=array();
$query_select_order=mysqli_query($con,"SELECT * FROM ecom_order WHERE customer_id='$id'");
while ($row=mysqli_fetch_array($query_select_order)) {

    $trans_id=$row['transaction_id'];
    $key['transaction_id']=$trans_id;
    $key['customer_id']=$row['customer_id'];
    $key['payment_method_id']=$row['payment_method_id'];
    $key['order_status']=$row['order_status'];
    $key['amount']=$row['amount'];
    $key['date_created']=$row['date_created'];
    $key['shipping_id']=$row['shipping_id'];
    $key['detail']=array();


//loop through the product and order details joined table

     $query_select_order_detail = mysqli_query($con, "SELECT ecom_order_items.*, ecom_product.pname,ecom_product.pimage1 FROM ecom_order_items JOIN ecom_product on 
    ecom_order_items.product_id = ecom_product.pid WHERE ecom_order_items.order_id = '$trans_id'");

    while ($row_order_detail = mysqli_fetch_array($query_select_order_detail)) {
        # code...
        $key['detail'][] = array(
            "id" => $row_order_detail['id'],
            "order_id" => $row_order_detail['order_id'],
            "product_id" => $row_order_detail['product_id'],
            "nameProduct" => $row_order_detail['pname'],
            "quantity" => $row_order_detail['quantity'],
            "unit_price" => $row_order_detail['unit_price'],
        );

    }

    array_push($response, $key);
    // code...
}

echo json_encode($response);






?>