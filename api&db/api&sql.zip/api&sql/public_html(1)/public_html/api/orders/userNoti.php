<?php

header("Access-Control-Allow-Origin: *");
include('../dbconnection.php');

// const key='MySecretKeyForEncryptionAndDecry';
// const iv='helloworldhellow';
// const method='aes-256-cbc';


// function encryp($text){
//     return openssl_encrypt($text, method, key, 0, iv);
// }


// function decryp($text){ 
//     return openssl_decrypt($text, method, key, 0, iv);
// }


// $orderid = mysqli_real_escape_string($con,decryp($_POST['orderid']));
// $uid = mysqli_real_escape_string($con,decryp($_POST['uid']));


$oid=$_POST['oid']; 
$uid=$_POST['uid'];
$status=$_POST['status'];

$user="select * from ecom_order where customer_id='$uid' AND transaction_id='$oid' ";
 $result = $con->query($user);
if ($result->num_rows > 0) {

        $sqlupdate = "UPDATE ecom_order SET order_status = '$status' WHERE customer_id = '$uid' AND transaction_id = '$oid'";
        if ($con->query($sqlupdate) === TRUE){

        $jay=mysqli_query($con,"insert into  notifications(title,body,user_id,status) values('ORDERID:$oid','Your Order $oid is $status','$uid','0')");

        if($jay){

            sendGCM("ORDERID:$oid","Your Order $oid is $status","users$uid","none","refresh");

            echo json_encode("ye");

        }else{

        echo json_encode("failed");

        }


        }else{

           

        } 

    }else{

        echo json_encode("no");

    }






function sendGCM($tit, $mess, $topic, $pageId, $pageName)

{



    $url = 'https://fcm.googleapis.com/fcm/send';


    $fields = array(

        "to" => '/topics/' . $topic,

        'priority' => 'high',

        'content_available' => true,



        'notification' => array(

            "body" =>  $mess,

            "title" =>  $tit,

            "click_action" => "FLUTTER_NOTIFICATION_CLICK",

            "sound" => "default"



        ),

        'data' => array(

            "pageid" => $pageId,

            "pagename" => $pageName

        )



    );


    $fields = json_encode($fields);

    $headers = array(

        'Authorization: key=' . "AAAAqub6EQE:APA91bF1yf67oXVnPfUOIKQAsl_Po4lo7KCrtWcGYFMHtlK6UlUZCM2NLFPRSGAeHxBW-g99oecUL-byYwapzdmF1caHKRqeztq81YdNgG4rKCgj5uPBNskS6-NaTvjD3qMMvDCBeJK6",

        'Content-Type: application/json'

    );



    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);



    $result = curl_exec($ch);

    return $result;

    curl_close($ch);

}

?>