<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){ 
    return openssl_decrypt($text, method, key, 0, iv);
}


$uid = mysqli_real_escape_string($con,decryp($_POST['uid']));
$fnem = mysqli_real_escape_string($con,decryp($_POST['fname']));
$lnem = mysqli_real_escape_string($con,decryp($_POST['lname']));
$num = mysqli_real_escape_string($con,decryp($_POST['phone']));
$cont = mysqli_real_escape_string($con,decryp($_POST['count']));
$add = mysqli_real_escape_string($con,decryp($_POST['add']));
$mail = mysqli_real_escape_string($con,decryp($_POST['ema']));


$user="select * from ecom_shipping_details where customer_id='$uid'";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){

 //echo json_encode("ERROR");

      $sqlupdate = "UPDATE ecom_shipping_details SET phone = '$num',address1='$add',city='$add',fname='$fnem',lname='$lnem',country='cont' WHERE customer_id = '$uid'";
      
        if ($con->query($sqlupdate) === TRUE){

            echo json_encode("up");

        }

 // $update="update ecom_shipping_details set phone='$num','address1='$add',city='$add',fname='$fnem',lname='$lnem',country='$cont' where customer_id='$uid'";
 // $ro=mysqli_query($con,$update);

 // if($ro){

 //    echo json_encode('up');
 // }

 

}else{

     $insert="insert into  ecom_shipping_details(customer_id,shipping_details,email,phone,address1,address2,city,fname,lname,country,amount)
     values('$uid','0','$mail','$num','$add','0','$add','$fnem','$lnem','$cont','0')";
     $res=mysqli_query($con,$insert);

     if($res){


        echo json_encode("add");

     }
    


}


?>