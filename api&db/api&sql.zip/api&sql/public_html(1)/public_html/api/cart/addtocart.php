<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$proid = mysqli_real_escape_string($con,decryp($_POST['proid']));
$slp = mysqli_real_escape_string($con,decryp($_POST['slp']));
$rp = mysqli_real_escape_string($con,decryp($_POST['rp']));
$qua = mysqli_real_escape_string($con,decryp($_POST['quant']));
$uid = mysqli_real_escape_string($con,decryp($_POST['uid']));
$prom = mysqli_real_escape_string($con,decryp($_POST['promoid']));
$other="";

$user="select * from cart where  product_id='$proid' and customer_id='$uid'";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){

echo json_encode("ERROR");	

}else{

$insert="insert into  cart(product_id,sale_price,regular_price,quantity,customer_id,promotion_id,other_note)
	 values('$proid','$slp','$rp','$qua','$uid','$prom','$other')";
$req=mysqli_query($con,$insert);

if($req){
    
    echo json_encode("ye");
}
}


?>