<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){ 
    return openssl_decrypt($text, method, key, 0, iv);
}


$uid = mysqli_real_escape_string($con,decryp($_POST['uid']));


$user="select * from ecom_shipping_details where customer_id='$uid'";
$run_user=mysqli_query($con,$user);
$userData=array();
$count=mysqli_num_rows($run_user);
if($count == "1"){

 echo json_encode("ERROR");

 
}


?>