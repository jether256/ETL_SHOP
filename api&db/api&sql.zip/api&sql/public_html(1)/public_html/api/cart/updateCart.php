<?php
 header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');


const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}




    $catid = mysqli_real_escape_string($con,decryp($_POST['catid']));
    $qua = mysqli_real_escape_string($con,decryp($_POST['quant']));

    
  
    $cart = mysqli_query($con, "SELECT * FROM cart WHERE cart_id = '$catid'");
    $result = mysqli_fetch_array($cart);

    $qty = $result['quantity'];

    if ($result) {
        # code...
        if ($qua == "adding") {
            # code...
            $update_add = mysqli_query($con, "UPDATE cart set quantity = quantity + 1 WHERE cart_id = '$catid'");
            if ($update_add) {
                
                echo json_encode("1");
            } else {
                 echo json_encode("0");
            }
        } else {
            # code...
            if ($qty == "1") {
                # code...
                $query_delete = mysqli_query($con, "DELETE FROM cart WHERE cart_id = '$catid'");
                if ($query_delete) {
                    
                echo json_encode("1");
                } else {
                    echo json_encode("0");
                }
            } else {
                # code...
                $update_minus = mysqli_query($con, "UPDATE cart set quantity = quantity - 1 WHERE cart_id = '$catid'");
                if ($update_minus) {
                    echo json_encode("1");
                } else {
                   echo json_encode("0");
                }
            }
        }
    } else {
       echo json_encode("0");
    }

?>