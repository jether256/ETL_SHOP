<?php
header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');



const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$id = mysqli_real_escape_string($con,decryp($_POST['uid']));
$mtd = mysqli_real_escape_string($con,decryp($_POST['mtd']));

//$id=$_POST['id'];
$today = date("Y-m-d H:i:s"); 
//random number
$ra=rand(10,999999999);

//Our string.
$string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

//Get the length of the string.
$stringLength = strlen($string);

//Generate a random index based on the string in question.
$randomIndex = mt_rand(0, $stringLength - 1);

//concatnate the random character with random number
$jery=$string[$randomIndex].''.$ra;



$user_cart=mysqli_query($con,"select * from cart where customer_id='$id'");
$user_cart_result=mysqli_fetch_array($user_cart);

if($user_cart_result){

    //loop thru shipping details to get shipping id
    $sel_ship=$user_cart=mysqli_query($con,"select shipping_id from ecom_shipping_details where customer_id='$id'");
    
    while ($low=mysqli_fetch_array($sel_ship)) {


        //SUM(quantity*sale_price)

        $sel_id=$low['shipping_id'];


                //loop through the cart to get total amount
             $total_price = mysqli_query($con, "SELECT SUM(quantity*sale_price) as Total FROM cart WHERE customer_id = '$id'");
             while ($tot=mysqli_fetch_array($total_price)) {

                $toto=$tot['Total'];



                         $insert_orders="insert into  ecom_order(customer_id,payment_method_id,order_status,transaction_id,amount,date_created,shipping_id,method)
                     values('$id','3','Pending','$jery','$toto','$today','$sel_id','$mtd')";
                     $orders_query=mysqli_query($con,$insert_orders);

                 if ($orders_query) {


                     $sel_cart_2=mysqli_query($con,"select * from cart where customer_id='$id'");

                    while ($cart=mysqli_fetch_array($sel_cart_2)) {

                        $proid = $cart['product_id'];
                        $quant = $cart['quantity'];
                        $price = $cart['sale_price'];

                       $insert_orders=mysqli_query($con,"insert into  ecom_order_items(order_id,product_id,quantity,unit_price)
                        values('$jery','$proid','$quant','$price')");

                    }


                        $del_cart = mysqli_query($con, "DELETE FROM cart WHERE customer_id = '$id'");
                        if($del_cart){

                          echo  json_encode('done');
                        }
                } else {
                    
                    echo json_encode('fail');
                }




             }



           



        // code...
    }




}else{

    echo json_encode('not');
}

?>