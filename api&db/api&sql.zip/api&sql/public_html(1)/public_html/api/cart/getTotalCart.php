<?php
 header("Access-Control-Allow-Origin: *");

include('../dbconnection.php');


const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}




     $id = mysqli_real_escape_string($con,decryp($_POST['uid']));
   $response = array();

    
    // $res=array();
    $total_price = mysqli_query($con, "SELECT SUM(quantity*sale_price) as Total FROM cart WHERE customer_id = '$id'");
    $result = mysqli_fetch_array($total_price);

     $response['Total']=$result['Total'];

    echo json_encode($response['Total']);
   
?>