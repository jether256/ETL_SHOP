<?php

header("Access-Control-Allow-Origin: *");
include('../dbconnection.php');


const key='MySecretKeyForEncryptionAndDecry';
const iv='helloworldhellow';
const method='aes-256-cbc';


function encryp($text){
    return openssl_encrypt($text, method, key, 0, iv);
}


function decryp($text){
    return openssl_decrypt($text, method, key, 0, iv);
}


$uid = mysqli_real_escape_string($con,decryp($_POST['id']));

$response = array();

//$uid = $_POST['id'];



$selectCart = mysqli_query($con, "SELECT cart.cart_id, cart.product_id, cart.sale_price,cart.regular_price,cart.quantity,cart.customer_id,cart.promotion_id,cart.other_note, ecom_product.pname, ecom_product.pimage1 FROM cart JOIN ecom_product on 
cart.product_id = ecom_product.pid WHERE cart.customer_id = '$uid'");


// $selectCart = mysqli_query($con, "SELECT ecom_favorite.fav_id,ecom_favorite.product_id,ecom_favorite.sale_price,ecom_favorite.regular_price, ecom_favorite.quantity,ecom_favorite.customer_id,ecom_favorite.promotion_id,ecom_favorite.other_note,ecom_product.pid,ecom_product.pname, ecom_product.pimage1 FROM ecom_favorite JOIN ecom_product on 
// ecom_favorite.product_id = ecom_product.pid WHERE ecom_favorite.customer_id = '$uid'");

 
while ($row = mysqli_fetch_array($selectCart)) {
   
   $response[]=$row;
}

echo json_encode($response);


?>