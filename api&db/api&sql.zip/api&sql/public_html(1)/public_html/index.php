<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edge Shop Notifications</title>
</head>
<body>
<h2>Edge Shop Firebase Notifications</a></h2>

<p id="token"></p>
<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-messaging.js"></script>
<script>
    var firebaseConfig = {
    apiKey: "AIzaSyDbJFAhO89QkrBuQ9BAqh0asOAh6Yj5Hms",
    authDomain: "edge-shop-web-63cc8.firebaseapp.com",
    projectId: "edge-shop-web-63cc8",
    storageBucket: "edge-shop-web-63cc8.appspot.com",
    messagingSenderId: "655688729561",
    appId: "1:655688729561:web:c35cf4107bd4750baa4fc8",
    measurementId: "G-WJSRVETDTQ"
    };
    firebase.initializeApp(firebaseConfig);
    const messaging=firebase.messaging();

    function IntitalizeFireBaseMessaging() {
        messaging
            .requestPermission()
            .then(function () {
                console.log("Notification Permission");
                return messaging.getToken();
            })
            .then(function (token) {
                console.log("Token : "+token);
                document.getElementById("token").innerHTML=token;
            })
            .catch(function (reason) {
                console.log(reason);
            });
    }

    messaging.onMessage(function (payload) {
        console.log(payload);
        const notificationOption={
            body:payload.notification.body,
            icon:payload.notification.icon
        };

        if(Notification.permission==="granted"){
            var notification=new Notification(payload.notification.title,notificationOption);

            notification.onclick=function (ev) {
                ev.preventDefault();
                window.open(payload.notification.click_action,'_blank');
                notification.close();
            }
        }

    });
    messaging.onTokenRefresh(function () {
        messaging.getToken()
            .then(function (newtoken) {
                console.log("New Token : "+ newtoken);
            })
            .catch(function (reason) {
                console.log(reason);
				//alert(reason);
            })
    })
    IntitalizeFireBaseMessaging();
</script>
</body>
</html>