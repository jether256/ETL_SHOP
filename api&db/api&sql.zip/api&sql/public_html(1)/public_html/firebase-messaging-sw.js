

importScripts('https://www.gstatic.com/firebasejs/7.14.6/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/7.14.6/firebase-messaging.js');

var firebaseConfig = {
	apiKey: "AIzaSyDbJFAhO89QkrBuQ9BAqh0asOAh6Yj5Hms",
    authDomain: "edge-shop-web-63cc8.firebaseapp.com",
    projectId: "edge-shop-web-63cc8",
    storageBucket: "edge-shop-web-63cc8.appspot.com",
    messagingSenderId: "655688729561",
    appId: "1:655688729561:web:c35cf4107bd4750baa4fc8",
    measurementId: "G-WJSRVETDTQ"
};

firebase.initializeApp(firebaseConfig);
const messaging=firebase.messaging();

messaging.setBackgroundMessageHandler(function (payload) {
    console.log(payload);
    const notification=JSON.parse(payload);
    const notificationOption={
        body:notification.body,
        icon:notification.icon
    };
    return self.registration.showNotification(payload.notification.title,notificationOption);
});


